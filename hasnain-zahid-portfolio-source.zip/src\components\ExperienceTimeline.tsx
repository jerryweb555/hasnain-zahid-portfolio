import React, { useState } from 'react';
import { experiences } from '../data/portfolioData';
import { ExperienceItem } from '../types';
import { 
  Briefcase, 
  Calendar, 
  MapPin, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  Sparkles, 
  Building2, 
  Tag, 
  Clock, 
  Layers
} from 'lucide-react';

export const ExperienceTimeline: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'support' | 'sales' | 'marketing' | 'ambassador'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(experiences[0].id);

  const filteredExperiences = filter === 'all' 
    ? experiences 
    : experiences.filter(e => e.category === filter);

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <section id="experience" className="py-24 relative bg-obsidian-900/60 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-sky/10 border border-brand-sky/20 text-brand-sky text-xs font-semibold uppercase tracking-wider mb-4">
              <Briefcase className="w-3.5 h-3.5" />
              06 — Professional Experience Timeline
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Cinematic Career Journey &{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-cyan-300 to-white">
                Front-Line Experience.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-400">CHRONOLOGICAL RECORD</span>
            <p className="text-xs text-slate-500">Each role documented with authentic responsibilities</p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-2 mb-14">
          {[
            { id: 'all', label: 'All Roles (5)' },
            { id: 'support', label: 'Customer Support' },
            { id: 'sales', label: 'Sales & Verification' },
            { id: 'marketing', label: 'Digital SEO & TikTok' },
            { id: 'ambassador', label: 'Brand Ambassador' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                filter === tab.id
                  ? 'bg-brand-sky text-obsidian-950 font-semibold shadow-md shadow-brand-sky/20'
                  : 'bg-obsidian-900 text-slate-300 hover:text-white border border-white/10 hover:border-white/20'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Timeline Container */}
        <div className="relative">
          {/* Vertical Glowing Timeline Guide Line */}
          <div className="hidden md:block absolute left-8 top-6 bottom-6 w-[2px] bg-gradient-to-b from-brand-sky via-brand-indigo to-emerald-400/20" />

          <div className="space-y-8">
            {filteredExperiences.map((item, index) => {
              const isExpanded = expandedId === item.id;

              return (
                <div
                  key={item.id}
                  className="relative md:pl-20 transition-all duration-300"
                >
                  {/* Timeline Node Point (Desktop) */}
                  <div className="hidden md:flex absolute left-[26px] top-7 -translate-x-1/2 w-8 h-8 rounded-full bg-obsidian-950 border-2 border-brand-sky items-center justify-center shadow-lg shadow-brand-sky/30 z-10">
                    <div className="w-2.5 h-2.5 rounded-full bg-brand-sky animate-pulse" />
                  </div>

                  {/* Experience Card */}
                  <div
                    className={`rounded-3xl glass-card border transition-all duration-300 overflow-hidden ${
                      isExpanded
                        ? 'border-brand-sky/40 bg-obsidian-900/90 shadow-2xl shadow-brand-sky/5'
                        : 'border-white/10 hover:border-white/20 bg-obsidian-900/50'
                    }`}
                  >
                    {/* Header Row: Clickable to expand/collapse */}
                    <div
                      onClick={() => toggleExpand(item.id)}
                      className="p-6 sm:p-8 cursor-pointer flex flex-col lg:flex-row lg:items-center justify-between gap-4 select-none"
                    >
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2.5">
                          <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-brand-sky/15 text-brand-sky border border-brand-sky/30">
                            {item.badgeText}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono text-slate-400 bg-white/5 border border-white/5">
                            {item.type}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-md text-[10px] font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">
                            {item.duration}
                          </span>
                        </div>

                        <h3 className="font-heading font-bold text-xl sm:text-2xl text-white tracking-tight">
                          {item.role}
                        </h3>

                        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                          <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                            <Building2 className="w-3.5 h-3.5 text-brand-sky" />
                            {item.company}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-slate-500" />
                            {item.period}
                          </span>
                          {item.location && (
                            <span className="flex items-center gap-1.5 hidden sm:flex">
                              <MapPin className="w-3.5 h-3.5 text-slate-500" />
                              {item.location}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Right action indicator */}
                      <div className="flex items-center gap-3 pt-2 lg:pt-0 border-t lg:border-t-0 border-white/5">
                        <span className="text-xs text-brand-sky font-medium hidden sm:inline">
                          {isExpanded ? 'Hide Details' : 'View Full Details'}
                        </span>
                        <div className={`w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 transition-transform duration-300 ${
                          isExpanded ? 'rotate-180 bg-brand-sky/20 text-brand-sky border-brand-sky/40' : ''
                        }`}>
                          <ChevronDown className="w-5 h-5" />
                        </div>
                      </div>
                    </div>

                    {/* Summary snippet always visible */}
                    <div className="px-6 sm:px-8 pb-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {item.summary}
                    </div>

                    {/* Expandable Details Area */}
                    {isExpanded && (
                      <div className="px-6 sm:px-8 pb-8 pt-4 border-t border-white/10 space-y-6 animate-in fade-in duration-300">
                        {/* Key Responsibilities */}
                        <div>
                          <h4 className="text-xs font-mono uppercase tracking-wider text-brand-sky mb-3 flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-brand-sky" />
                            Primary Responsibilities & Workflows
                          </h4>
                          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {item.responsibilities.map((resp, rIdx) => (
                              <li
                                key={rIdx}
                                className="flex items-start gap-2.5 p-3 rounded-xl bg-obsidian-950/70 border border-white/5 text-xs text-slate-300 leading-relaxed"
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-brand-sky mt-1.5 shrink-0" />
                                <span>{resp}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Skills & Competencies Acquired */}
                        <div>
                          <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                            <Tag className="w-3.5 h-3.5 text-emerald-400" />
                            Core Capabilities Practiced
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {item.skillsGained.map((sk, sIdx) => (
                              <span
                                key={sIdx}
                                className="px-3 py-1 rounded-lg text-xs font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
