export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location?: string;
  type: 'Full-time' | 'Freelance' | 'Campaign / Project';
  period: string;
  duration: string;
  category: 'support' | 'sales' | 'marketing' | 'ambassador';
  summary: string;
  responsibilities: string[];
  skillsGained: string[];
  badgeText: string;
}

export interface SkillCategory {
  title: string;
  description: string;
  iconName: string;
  skills: {
    name: string;
    level: string;
    description: string;
    keywords?: string[];
  }[];
}

export interface CertificateItem {
  id: string;
  title: string;
  issuer: string;
  date: string;
  duration?: string;
  instructor?: string;
  credentialId?: string;
  verifyUrl?: string;
  badgeType: 'Completion Badge' | 'Certificate of Completion';
  fileUrl: string;
  fileType: 'image' | 'pdf';
  previewImageUrl?: string;
  description: string;
  skillsHighlighted: string[];
  featured: boolean;
}

export interface EducationItem {
  degree: string;
  field: string;
  institution: string;
  boardOrAuthority: string;
  period: string;
  status: string;
  gradeOrMarks?: string;
  highlights: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  category: 'AI Prototype' | 'SEO Case Study' | 'Creator Consulting';
  badge: 'Demonstration Prototype' | 'Client Consulting Case Study' | 'Digital Strategy';
  shortDesc: string;
  fullDesc: string;
  problem: string;
  solution: string;
  keyOutcomes: string[];
  techOrTools: string[];
  isDemoPrototype: boolean;
}

export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  icon: string;
  category: string;
}
