import React from 'react';
import { journeyMilestones } from '../data/portfolioData';
import { 
  Milestone, 
  Compass, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Flame,
  ShieldCheck,
  Brain
} from 'lucide-react';

export const JourneySection: React.FC = () => {
  return (
    <section id="journey" className="py-24 relative bg-obsidian-900/60 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-violet/10 border border-brand-violet/20 text-brand-violet text-xs font-semibold uppercase tracking-wider mb-4">
              <Compass className="w-3.5 h-3.5" />
              12 — Professional Evolution & Journey
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              A Deliberate Trajectory of{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-violet via-brand-sky to-white">
                Discipline & Growth.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">CAREER ROADMAP</span>
            <p className="text-xs text-slate-400">From academic groundwork to front-line mastery</p>
          </div>
        </div>

        {/* Journey Timeline Progression Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {journeyMilestones.map((m, idx) => (
            <div
              key={idx}
              className="relative p-7 rounded-3xl glass-card border border-white/10 hover:border-brand-sky/40 transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono px-3 py-1 rounded-full bg-brand-sky/15 text-brand-sky border border-brand-sky/30">
                    Phase 0{idx + 1}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {m.timeframe}
                  </span>
                </div>

                <span className="text-xs font-medium text-slate-300 block mb-1">
                  {m.phase}
                </span>
                <h3 className="font-heading font-bold text-lg text-white group-hover:text-brand-sky transition-colors mb-3 leading-snug">
                  {m.headline}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {m.description}
                </p>
              </div>

              <div className="pt-5 mt-5 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
                <span>Verified Milestones</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
            </div>
          ))}
        </div>

        {/* Growth Philosophy Quote Callout */}
        <div className="mt-14 p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-obsidian-950 via-obsidian-900 to-obsidian-950 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <span className="text-xs font-mono text-brand-sky uppercase tracking-wider">
              CORE MOTTO
            </span>
            <p className="font-heading text-xl sm:text-2xl font-bold text-white leading-snug">
              "Every conversation is an opportunity to solve a problem, build trust, and leave a positive lasting impression."
            </p>
            <p className="text-xs text-slate-400">
              Hasnain Zahid — Customer Support & Sales Communication Professional
            </p>
          </div>

          <a
            href="#contact"
            className="shrink-0 px-6 py-3.5 rounded-xl text-xs font-semibold text-obsidian-950 bg-gradient-to-r from-brand-sky to-white hover:from-white hover:to-brand-sky transition-all shadow-md shadow-brand-sky/20"
          >
            Start a Conversation
          </a>
        </div>

      </div>
    </section>
  );
};
