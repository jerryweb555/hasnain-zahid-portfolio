import React, { useState } from 'react';
import { certifications } from '../data/portfolioData';
import { CertificateItem } from '../types';
import { CertificateModal } from './CertificateModal';
import { 
  Award, 
  ExternalLink, 
  Calendar, 
  Clock, 
  Eye, 
  CheckCircle2, 
  Sparkles,
  FileText,
  ShieldCheck
} from 'lucide-react';

export const CertificatesSection: React.FC = () => {
  const [selectedCert, setSelectedCert] = useState<CertificateItem | null>(null);

  const getIssuerBadge = (issuer: string) => {
    switch (issuer) {
      case 'Google Cloud':
        return {
          bg: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
          gradient: 'from-blue-500/20 to-sky-500/10',
          tag: 'Official Google Badge'
        };
      case 'Anthropic':
        return {
          bg: 'bg-amber-500/10 border-amber-500/20 text-amber-400',
          gradient: 'from-amber-500/20 to-orange-500/10',
          tag: 'Anthropic Education'
        };
      default:
        return {
          bg: 'bg-purple-500/10 border-purple-500/20 text-purple-400',
          gradient: 'from-purple-500/20 to-pink-500/10',
          tag: 'Udemy Certified'
        };
    }
  };

  return (
    <section id="certificates" className="py-24 relative bg-obsidian-900/60 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-4">
              <Award className="w-3.5 h-3.5" />
              08 — Certifications & Verified Credentials
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Four Accredited Credentials in{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-emerald-400 to-white">
                Customer Care & AI Foundations.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-400">100% VERIFIED FILES</span>
            <p className="text-xs text-slate-500">Original certificates and completion badges accessible</p>
          </div>
        </div>

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {certifications.map((cert) => {
            const badgeMeta = getIssuerBadge(cert.issuer);

            return (
              <div
                key={cert.id}
                className="group relative rounded-3xl glass-card border border-white/10 hover:border-brand-sky/40 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-black/60 flex flex-col justify-between overflow-hidden"
              >
                {/* Visual Certificate Card Header / Preview Area */}
                <div 
                  onClick={() => setSelectedCert(cert)}
                  className="relative p-6 sm:p-7 border-b border-white/10 cursor-pointer overflow-hidden bg-gradient-to-br from-obsidian-950 to-obsidian-900 flex flex-col justify-between min-h-[220px]"
                >
                  {/* Subtle decorative glow */}
                  <div className={`absolute top-0 right-0 w-44 h-44 bg-gradient-to-br ${badgeMeta.gradient} rounded-full blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-500`} />

                  <div className="relative z-10 flex items-start justify-between gap-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider border ${badgeMeta.bg}`}>
                      {cert.issuer}
                    </span>

                    <span className="px-2.5 py-1 rounded-md text-[11px] font-mono text-slate-400 bg-white/5 border border-white/5 flex items-center gap-1.5">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      {cert.date}
                    </span>
                  </div>

                  {/* Visual preview centerpiece */}
                  <div className="relative z-10 my-4 flex items-center gap-4">
                    {cert.fileType === 'image' ? (
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-xl shrink-0 border border-white/20 group-hover:scale-105 transition-transform">
                        <img
                          src={cert.fileUrl}
                          alt={cert.title}
                          className="w-full h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-obsidian-950 border border-brand-sky/30 flex flex-col items-center justify-center text-brand-sky shrink-0 shadow-xl group-hover:scale-105 transition-transform">
                        <FileText className="w-8 h-8 text-brand-sky mb-0.5" />
                        <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400">PDF</span>
                      </div>
                    )}

                    <div>
                      <h3 className="font-heading font-bold text-xl sm:text-2xl text-white group-hover:text-brand-sky transition-colors leading-tight">
                        {cert.title}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        {cert.badgeType}
                      </p>
                    </div>
                  </div>

                  {/* Metadata Row: Instructor / Duration */}
                  <div className="relative z-10 flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-2 border-t border-white/5">
                    {cert.instructor && (
                      <span>Instructor: <strong className="text-slate-300 font-medium">{cert.instructor}</strong></span>
                    )}
                    {cert.duration && (
                      <span className="flex items-center gap-1 text-slate-400">
                        <Clock className="w-3 h-3 text-brand-sky" />
                        {cert.duration}
                      </span>
                    )}
                    {cert.credentialId && (
                      <span className="font-mono text-[10px] text-slate-400 truncate max-w-[200px]">
                        ID: {cert.credentialId.slice(0, 14)}...
                      </span>
                    )}
                  </div>

                  {/* Hover visual overlay */}
                  <div className="absolute inset-0 bg-brand-sky/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex items-center justify-center">
                    <span className="px-4 py-2 rounded-xl bg-obsidian-950/90 border border-brand-sky/40 text-brand-sky text-xs font-semibold shadow-xl flex items-center gap-2">
                      <Eye className="w-4 h-4" /> Click to Inspect Credential
                    </span>
                  </div>
                </div>

                {/* Card Bottom: Description & CTAs */}
                <div className="p-6 sm:p-7 flex flex-col justify-between flex-1 space-y-6">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {cert.description}
                  </p>

                  <div className="space-y-4 pt-2">
                    {/* Skills Tagged */}
                    <div className="flex flex-wrap gap-1.5">
                      {cert.skillsHighlighted.map((skill, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-white/5 text-slate-300 border border-white/5"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                      <button
                        onClick={() => setSelectedCert(cert)}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-obsidian-800 hover:bg-obsidian-700 border border-white/10 hover:border-brand-sky/40 transition-all shadow-sm"
                      >
                        <Eye className="w-3.5 h-3.5 text-brand-sky" />
                        <span>View Certificate</span>
                      </button>

                      <a
                        href={cert.fileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors"
                        title="Open Original File Directly"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Certificate Modal */}
      <CertificateModal
        cert={selectedCert}
        onClose={() => setSelectedCert(null)}
      />
    </section>
  );
};
