import React, { useState, useEffect } from 'react';
import { personalInfo } from '../data/portfolioData';
import { Menu, X, Download, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  onOpenCertModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      const sections = [
        'hero',
        'intro',
        'about',
        'overview',
        'experience',
        'skills',
        'certificates',
        'education',
        'projects',
        'services',
        'journey',
        'contact'
      ];

      const scrollPosition = window.scrollY + 200;
      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Experience', href: '#experience' },
    { name: 'Skills', href: '#skills' },
    { name: 'Certifications', href: '#certificates' },
    { name: 'Education', href: '#education' },
    { name: 'Projects', href: '#projects' },
    { name: 'Services', href: '#services' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'glass-nav py-3.5 shadow-2xl shadow-black/40'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo / Brand Name */}
          <a
            href="#hero"
            className="group flex items-center gap-3 text-left focus:outline-none focus:ring-2 focus:ring-brand-sky/50 rounded-lg p-1"
          >
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-brand-sky via-brand-indigo to-brand-violet p-[1px] shadow-lg shadow-brand-sky/20 group-hover:shadow-brand-sky/40 transition-all duration-300">
              <div className="w-full h-full bg-obsidian-900 rounded-[11px] flex items-center justify-center">
                <span className="font-heading font-extrabold text-base tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-brand-sky to-white">
                  HZ
                </span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-heading font-bold text-base tracking-tight text-white group-hover:text-brand-sky transition-colors">
                  {personalInfo.name}
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1"></span>
                  Verified
                </span>
              </div>
              <p className="text-[11px] text-slate-400 tracking-wide font-light hidden sm:block">
                Customer Support & Sales Professional
              </p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-obsidian-900/60 p-1.5 rounded-full border border-white/10 backdrop-blur-md">
            {navLinks.map((link) => {
              const targetId = link.href.replace('#', '');
              const isActive = activeSection === targetId;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-brand-sky/20 to-brand-indigo/20 text-brand-sky border border-brand-sky/30 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link.name}
                </a>
              );
            })}
          </nav>

          {/* Actions: Download CV & Contact CTA */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href={personalInfo.cvUrl}
              download="Hasnain_Zahid_CV.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-slate-300 bg-obsidian-800/80 hover:bg-obsidian-700/80 border border-white/10 hover:border-white/20 hover:text-white transition-all shadow-sm group"
              title="Download Hasnain Zahid's Professional CV"
            >
              <Download className="w-3.5 h-3.5 text-brand-sky group-hover:translate-y-0.5 transition-transform" />
              <span>Download CV</span>
            </a>

            <a
              href="#contact"
              className="relative inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-obsidian-950 bg-gradient-to-r from-brand-sky via-cyan-300 to-white hover:from-white hover:to-brand-sky transition-all duration-300 shadow-md shadow-brand-sky/25 hover:shadow-brand-sky/40 hover:scale-[1.02]"
            >
              <Sparkles className="w-3.5 h-3.5 text-obsidian-950" />
              <span>Get in Touch</span>
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-obsidian-800/80 border border-white/10 text-slate-300 hover:text-white focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 border-b border-white/10 bg-obsidian-950/95 backdrop-blur-2xl px-5 py-6 space-y-4 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs text-slate-300 font-medium">{personalInfo.status}</span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Bahawalpur, PK</span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
            <a
              href={personalInfo.cvUrl}
              download="Hasnain_Zahid_CV.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium text-white bg-obsidian-800 border border-white/10 hover:bg-obsidian-700"
            >
              <Download className="w-4 h-4 text-brand-sky" />
              Download Official CV (PDF)
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-obsidian-950 bg-gradient-to-r from-brand-sky to-white"
            >
              Connect Directly
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
