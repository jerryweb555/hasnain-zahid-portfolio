import React, { useState } from 'react';
import { projectsList } from '../data/portfolioData';
import { ProjectItem } from '../types';
import { ProjectModal } from './ProjectModal';
import { 
  FolderGit2, 
  ArrowUpRight, 
  Sparkles, 
  Bot, 
  Youtube, 
  Video, 
  CheckCircle2, 
  AlertCircle,
  Eye
} from 'lucide-react';

export const ProjectsSection: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const getProjectIcon = (category: string) => {
    switch (category) {
      case 'AI Prototype':
        return Bot;
      case 'SEO Case Study':
        return Youtube;
      default:
        return Video;
    }
  };

  return (
    <section id="projects" className="py-24 relative bg-obsidian-900/60 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-sky/10 border border-brand-sky/20 text-brand-sky text-xs font-semibold uppercase tracking-wider mb-4">
              <FolderGit2 className="w-3.5 h-3.5" />
              10 — Featured Projects & Case Studies
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Demonstrated Workflows in{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-cyan-300 to-white">
                Customer Care & Digital Growth.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">ETHICAL DISCLOSURE</span>
            <p className="text-xs text-slate-400">Prototypes and case studies clearly demarcated</p>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {projectsList.map((project) => {
            const Icon = getProjectIcon(project.category);

            return (
              <div
                key={project.id}
                className="group relative rounded-3xl glass-card border border-white/10 hover:border-brand-sky/40 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-black/60 flex flex-col justify-between overflow-hidden"
              >
                {/* Project Header Bar */}
                <div className="p-7 border-b border-white/10 bg-gradient-to-b from-obsidian-950/80 to-transparent">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-brand-sky/15 border border-brand-sky/30 flex items-center justify-center text-brand-sky group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                      project.isDemoPrototype
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {project.badge}
                    </span>
                  </div>

                  <span className="text-xs font-mono text-slate-400 block mb-1">
                    {project.category}
                  </span>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-brand-sky transition-colors">
                    {project.title}
                  </h3>
                </div>

                {/* Project Content */}
                <div className="p-7 flex flex-col justify-between flex-1 space-y-6">
                  <div>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                      {project.shortDesc}
                    </p>

                    {/* Key outcomes snippet */}
                    <ul className="space-y-2 text-xs text-slate-400 pt-2 border-t border-white/5">
                      {project.keyOutcomes.slice(0, 2).map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-brand-sky shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tech Tags & CTA */}
                  <div className="space-y-4 pt-4 border-t border-white/10">
                    <div className="flex flex-wrap gap-1.5">
                      {project.techOrTools.map((t, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-white/5 text-slate-400 border border-white/5"
                        >
                          {t}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={() => setSelectedProject(project)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-semibold text-white bg-obsidian-800 hover:bg-obsidian-700 border border-white/10 hover:border-brand-sky/40 transition-all shadow-sm group/btn"
                    >
                      <Eye className="w-3.5 h-3.5 text-brand-sky" />
                      <span>Explore Project Breakdown</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Project Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
