import React from 'react';
import { servicesList } from '../data/portfolioData';
import { 
  Briefcase, 
  Headset, 
  CheckCircle2, 
  Youtube, 
  Video, 
  Sparkles, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Headset':
        return Headset;
      case 'CheckCircle2':
        return ShieldCheck;
      case 'Youtube':
        return Youtube;
      case 'Video':
        return Video;
      default:
        return Sparkles;
    }
  };

  return (
    <section id="services" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-4">
              <Briefcase className="w-3.5 h-3.5" />
              11 — Professional Services & Offerings
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              High-Impact Capabilities for{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-brand-sky to-white">
                Teams, Campaigns & Creators.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">ENGAGEMENT READY</span>
            <p className="text-xs text-slate-400">Available for remote contracts & consulting</p>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-14">
          {servicesList.map((service, idx) => {
            const Icon = getServiceIcon(service.icon);

            return (
              <div
                key={service.id}
                className="group relative p-8 rounded-3xl glass-card border border-white/10 hover:border-brand-sky/40 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-black/60 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-brand-sky/15 border border-brand-sky/30 flex items-center justify-center text-brand-sky group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-white/5 text-slate-400 border border-white/5">
                      {service.category}
                    </span>
                  </div>

                  <span className="text-xs font-medium text-brand-sky block mb-1">
                    {service.subtitle}
                  </span>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-brand-sky transition-colors mb-3">
                    {service.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Deliverables List */}
                  <div className="space-y-2 pt-4 border-t border-white/5">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block mb-2">
                      Key Deliverables
                    </span>
                    {service.deliverables.map((deliv, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-brand-sky shrink-0 mt-0.5" />
                        <span>{deliv}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-white/10">
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-sky hover:text-white transition-colors group/link"
                  >
                    <span>Discuss this service</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/link:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
