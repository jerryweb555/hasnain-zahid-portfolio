import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const Hero3D: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Check reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Dimensions
    let width = container.clientWidth;
    let height = container.clientHeight;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07090e, 0.05);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 7;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    container.appendChild(renderer.domElement);

    // Root Group for interactive rotation
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. Central Core: High-tech faceted crystal (Icosahedron)
    const coreGeometry = new THREE.IcosahedronGeometry(1.4, 1);
    
    // Core solid translucent material
    const coreMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x0a192f,
      emissive: 0x0284c7,
      emissiveIntensity: 0.35,
      roughness: 0.15,
      metalness: 0.85,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      wireframe: false,
      transparent: true,
      opacity: 0.85,
    });
    const coreMesh = new THREE.Mesh(coreGeometry, coreMaterial);
    mainGroup.add(coreMesh);

    // Core Wireframe overlay
    const wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const wireframeMesh = new THREE.Mesh(coreGeometry, wireframeMaterial);
    wireframeMesh.scale.setScalar(1.002);
    mainGroup.add(wireframeMesh);

    // 2. Orbital Rings (Layered depth & motion)
    const ringsGroup = new THREE.Group();
    mainGroup.add(ringsGroup);

    const createRing = (radius: number, tube: number, color: number, tiltX: number, tiltY: number) => {
      const ringGeo = new THREE.TorusGeometry(radius, tube, 16, 100);
      const ringMat = new THREE.MeshStandardMaterial({
        color: color,
        emissive: color,
        emissiveIntensity: 0.6,
        roughness: 0.2,
        metalness: 0.8,
        transparent: true,
        opacity: 0.7,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = tiltX;
      ringMesh.rotation.y = tiltY;
      return ringMesh;
    };

    const ring1 = createRing(2.1, 0.02, 0x38bdf8, Math.PI / 3, Math.PI / 6);
    const ring2 = createRing(2.5, 0.015, 0x818cf8, -Math.PI / 4, Math.PI / 3);
    const ring3 = createRing(2.9, 0.012, 0x06b6d4, Math.PI / 6, -Math.PI / 4);

    ringsGroup.add(ring1);
    ringsGroup.add(ring2);
    ringsGroup.add(ring3);

    // 3. Orbital Data Nodes (Little floating spheres on orbits)
    const nodeGeo = new THREE.SphereGeometry(0.06, 16, 16);
    const nodeMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x38bdf8,
      emissiveIntensity: 1.0,
      metalness: 0.2,
      roughness: 0.1,
    });

    const nodesCount = 6;
    const nodes: THREE.Mesh[] = [];
    for (let i = 0; i < nodesCount; i++) {
      const node = new THREE.Mesh(nodeGeo, nodeMat);
      mainGroup.add(node);
      nodes.push(node);
    }

    // 4. Background Constellation Particles
    const particleCount = 200;
    const particleGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    const c1 = new THREE.Color(0x38bdf8);
    const c2 = new THREE.Color(0x818cf8);
    const c3 = new THREE.Color(0xffffff);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10 - 2;

      const pickColor = Math.random() > 0.6 ? c1 : Math.random() > 0.3 ? c2 : c3;
      particleColors[i * 3] = pickColor.r;
      particleColors[i * 3 + 1] = pickColor.g;
      particleColors[i * 3 + 2] = pickColor.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // 5. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x38bdf8, 3, 20);
    pointLight1.position.set(5, 5, 5);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x818cf8, 2.5, 20);
    pointLight2.position.set(-5, -4, 3);
    scene.add(pointLight2);

    const pointLight3 = new THREE.PointLight(0x10b981, 1.8, 15);
    pointLight3.position.set(0, 4, -3);
    scene.add(pointLight3);

    // Interaction State
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const onPointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / height) * 2 - 1);

      if (isDraggingRef.current) {
        const deltaX = e.clientX - previousMousePositionRef.current.x;
        const deltaY = e.clientY - previousMousePositionRef.current.y;
        mainGroup.rotation.y += deltaX * 0.008;
        mainGroup.rotation.x += deltaY * 0.008;
        previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
      } else {
        targetX = x * 0.35;
        targetY = y * 0.35;
      }
    };

    const onPointerDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onPointerUp = () => {
      isDraggingRef.current = false;
    };

    container.addEventListener('mousemove', onPointerMove);
    container.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mouseup', onPointerUp);

    // Touch support for 360 mobile drag
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDraggingRef.current = true;
        previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (isDraggingRef.current && e.touches.length === 1) {
        const deltaX = e.touches[0].clientX - previousMousePositionRef.current.x;
        const deltaY = e.touches[0].clientY - previousMousePositionRef.current.y;
        mainGroup.rotation.y += deltaX * 0.008;
        mainGroup.rotation.x += deltaY * 0.008;
        previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchEnd = () => {
      isDraggingRef.current = false;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      if (!prefersReducedMotion) {
        if (!isDraggingRef.current) {
          // Smooth inertia towards mouse target
          mouseX += (targetX - mouseX) * 0.05;
          mouseY += (targetY - mouseY) * 0.05;

          mainGroup.rotation.y += 0.004;
          mainGroup.rotation.x = THREE.MathUtils.lerp(mainGroup.rotation.x, mouseY * 0.8, 0.05);
          mainGroup.rotation.z = THREE.MathUtils.lerp(mainGroup.rotation.z, -mouseX * 0.5, 0.05);
        }

        // Inner core pulsing & gentle counter-spin
        coreMesh.rotation.y -= 0.003;
        coreMesh.rotation.z += 0.002;
        wireframeMesh.rotation.y -= 0.003;
        wireframeMesh.rotation.z += 0.002;

        const pulse = Math.sin(elapsedTime * 2) * 0.04 + 1;
        coreMesh.scale.setScalar(pulse);
        wireframeMesh.scale.setScalar(pulse * 1.002);

        // Individual ring rotations
        ring1.rotation.z += 0.008;
        ring2.rotation.z -= 0.006;
        ring3.rotation.z += 0.004;

        // Position nodes dynamically along orbital trajectories
        nodes.forEach((node, idx) => {
          const speed = 0.6 + idx * 0.15;
          const angle = elapsedTime * speed + (idx * Math.PI * 2) / nodesCount;
          const radius = 2.1 + (idx % 3) * 0.4;
          node.position.x = Math.cos(angle) * radius;
          node.position.y = Math.sin(angle) * Math.cos(idx * 0.8) * radius;
          node.position.z = Math.sin(angle) * Math.sin(idx * 0.8) * radius;
        });

        // Slow ambient particle drift
        particles.rotation.y = elapsedTime * 0.02;
      }

      renderer.render(scene, camera);
    };

    animate();

    // Clean up
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', onPointerMove);
      container.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mouseup', onPointerUp);
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }

      // Dispose geometries & materials
      coreGeometry.dispose();
      coreMaterial.dispose();
      wireframeMaterial.dispose();
      particleGeometry.dispose();
      particleMaterial.dispose();
      nodeGeo.dispose();
      nodeMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full h-full min-h-[420px] lg:min-h-[560px] flex items-center justify-center select-none cursor-grab active:cursor-grabbing">
      {/* 3D Canvas Mount Point */}
      <div ref={mountRef} className="w-full h-full absolute inset-0 z-10" />

      {/* Decorative Interactive Hint Overlay */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center gap-2 px-3 py-1 rounded-full bg-obsidian-900/70 border border-white/10 backdrop-blur-md text-[11px] text-slate-400">
        <span className="w-1.5 h-1.5 rounded-full bg-brand-sky animate-ping" />
        <span>360° Interactive Core — Drag to rotate visual</span>
      </div>

      {/* Background Soft Glow Aura */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-brand-sky/15 blur-[100px] pointer-events-none -z-0" />
      <div className="absolute w-60 h-60 rounded-full bg-brand-indigo/15 blur-[90px] pointer-events-none -z-0 translate-x-12 translate-y-12" />
    </div>
  );
};
