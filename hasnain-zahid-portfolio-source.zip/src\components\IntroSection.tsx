import React from 'react';
import { personalInfo } from '../data/portfolioData';
import { 
  PhoneCall, 
  Users2, 
  TrendingUp, 
  BrainCircuit, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles,
  ArrowUpRight
} from 'lucide-react';

export const IntroSection: React.FC = () => {
  const pillars = [
    {
      title: 'Customer Dialogue & Verification',
      subtitle: 'Final Expense Campaigns',
      description: 'Extensive hands-on execution in high-tempo customer verification and closing workflows. Mastered active inquiry handling, objective compliance, and calm de-escalation under strict international campaign standards.',
      icon: PhoneCall,
      accent: 'from-sky-500/20 to-blue-600/10',
      borderAccent: 'border-sky-500/30',
      iconColor: 'text-sky-400',
      tag: '6M Verification + 3M Closing'
    },
    {
      title: 'Field Brand Representation',
      subtitle: 'PTC Project Ambassador',
      description: 'Face-to-face community interaction and brand advocacy. Built interpersonal agility, on-the-spot communication resilience, teamwork, and brand compliance under direct public scrutiny.',
      icon: Users2,
      accent: 'from-emerald-500/20 to-teal-600/10',
      borderAccent: 'border-emerald-500/30',
      iconColor: 'text-emerald-400',
      tag: '3 Months Field Outreach'
    },
    {
      title: 'Digital Marketing & Creator Consulting',
      subtitle: 'TikTok Advisory & YouTube SEO',
      description: 'Supported 10+ content creators with organic growth mechanics, retention optimization, and monetization guidance. Conducted keyword research, title copywriting, and metadata indexing for YouTube discovery.',
      icon: TrendingUp,
      accent: 'from-indigo-500/20 to-violet-600/10',
      borderAccent: 'border-indigo-500/30',
      iconColor: 'text-indigo-400',
      tag: '10+ Accounts Advised'
    },
    {
      title: 'Certified AI Fluency & Modern Tech',
      subtitle: 'Google Cloud & Anthropic',
      description: 'Certified foundational mastery of Generative AI principles, LLM behaviors, and responsible deployment frameworks. Bridging traditional customer operations with modern generative workflows.',
      icon: BrainCircuit,
      accent: 'from-amber-500/20 to-orange-600/10',
      borderAccent: 'border-amber-500/30',
      iconColor: 'text-amber-400',
      tag: 'Google Cloud & Anthropic Certified'
    }
  ];

  return (
    <section id="intro" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-sky/10 border border-brand-sky/20 text-brand-sky text-xs font-semibold uppercase tracking-wider mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              03 — Professional Introduction
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Where Human Empathy Meets{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky to-brand-indigo">
                Digital Discovery & AI Literacy.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-400 block">HASNAIN ZAHID — PROFILE SPEC</span>
            <span className="text-xs text-brand-sky font-medium">Customer-First • Data-Guided • AI-Ready</span>
          </div>
        </div>

        {/* Narrative Manifesto Box */}
        <div className="relative p-8 sm:p-10 rounded-3xl glass-card border border-white/10 shadow-2xl mb-14 overflow-hidden">
          {/* Subtle decorative gradient */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-brand-sky/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 max-w-4xl space-y-5">
            <p className="text-lg sm:text-xl text-slate-200 font-normal leading-relaxed">
              In a digital landscape filled with automated noise, true value lies at the intersection of{' '}
              <strong className="text-white font-semibold">active human listening</strong>,{' '}
              <strong className="text-white font-semibold">flawless process compliance</strong>, and the ability to leverage{' '}
              <strong className="text-brand-sky font-semibold">emerging AI tools</strong>.
            </p>
            <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
              My background represents a versatile synthesis of front-line customer engagement: from verifying and 
              closing prospective clients on fast-paced American insurance campaigns to guiding content creators through 
              the nuances of digital discoverability, TikTok monetization rules, and YouTube keyword indexing. Rather than 
              treating technology and customer service as separate worlds, I integrate them to deliver calm, trustworthy, 
              and results-oriented experiences.
            </p>
          </div>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div
                key={idx}
                className="group relative p-6 rounded-2xl bg-obsidian-900/70 border border-white/10 hover:border-white/20 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/50 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${pillar.accent} border ${pillar.borderAccent} flex items-center justify-center ${pillar.iconColor} group-hover:scale-108 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-white/5 text-slate-400 border border-white/5">
                      0{idx + 1}
                    </span>
                  </div>

                  <span className="inline-block text-[11px] font-medium text-brand-sky mb-1">
                    {pillar.subtitle}
                  </span>
                  <h3 className="font-heading font-bold text-lg text-white group-hover:text-brand-sky transition-colors mb-3">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {pillar.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[11px] font-medium text-slate-300">
                    {pillar.tag}
                  </span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400/80" />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
