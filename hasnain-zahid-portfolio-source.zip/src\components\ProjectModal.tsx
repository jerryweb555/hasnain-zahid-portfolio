import React, { useEffect } from 'react';
import { ProjectItem } from '../types';
import { 
  X, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  HelpCircle, 
  Wrench, 
  Lightbulb,
  ExternalLink
} from 'lucide-react';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-10 animate-in fade-in duration-200">
      {/* Dark backdrop */}
      <div 
        className="fixed inset-0 bg-obsidian-950/85 backdrop-blur-xl transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Dialog Content */}
      <div className="relative w-full max-w-3xl max-h-[92vh] bg-obsidian-900 border border-white/15 rounded-3xl shadow-2xl flex flex-col overflow-hidden z-10">
        
        {/* Top Header */}
        <div className="p-6 sm:px-8 border-b border-white/10 flex items-center justify-between bg-obsidian-950/70">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                project.isDemoPrototype
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : 'bg-brand-sky/10 text-brand-sky border border-brand-sky/20'
              }`}>
                {project.badge}
              </span>
              <span className="text-xs font-mono text-slate-500">• {project.category}</span>
            </div>
            <h3 className="font-heading font-bold text-xl sm:text-2xl text-white">
              {project.title}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors focus:outline-none"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-7">
          
          {/* Important Transparency Notice */}
          {project.isDemoPrototype ? (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3 text-xs text-amber-200 leading-relaxed">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block text-amber-300 mb-0.5">Prototype & Concept Demonstration</strong>
                This project represents a designed AI workflow demonstration prototype. It showcases practical customer support AI logic, patient intake prompts, and appointment triage, and is not presented as paid commercial client work.
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-brand-sky/10 border border-brand-sky/20 flex items-start gap-3 text-xs text-brand-sky leading-relaxed">
              <CheckCircle2 className="w-5 h-5 text-brand-sky shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block text-white mb-0.5">Authentic Freelance Consulting Case Study</strong>
                Based on actual freelance client support and digital optimization methodologies applied across creator accounts.
              </div>
            </div>
          )}

          {/* Overview Statement */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Project Overview
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed">
              {project.fullDesc}
            </p>
          </div>

          {/* Challenge & Solution Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-obsidian-950/80 border border-white/5 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-400 font-mono uppercase tracking-wider">
                <HelpCircle className="w-4 h-4" /> The Challenge / Problem
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {project.problem}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-obsidian-950/80 border border-white/5 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 font-mono uppercase tracking-wider">
                <Lightbulb className="w-4 h-4" /> The Strategic Solution
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {project.solution}
              </p>
            </div>
          </div>

          {/* Key Deliverables & Outcomes */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-brand-sky" />
              Key Deliverables & Methodological Highlights
            </h4>
            <div className="space-y-2">
              {project.keyOutcomes.map((outcome, oIdx) => (
                <div
                  key={oIdx}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-obsidian-950 border border-white/5 text-xs text-slate-300 leading-relaxed"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-brand-sky mt-1.5 shrink-0" />
                  <span>{outcome}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Technologies & Tools Used */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-2">
              <Wrench className="w-3.5 h-3.5 text-brand-indigo" />
              Tools, Standards & Frameworks Applied
            </h4>
            <div className="flex flex-wrap gap-2">
              {project.techOrTools.map((tech, tIdx) => (
                <span
                  key={tIdx}
                  className="px-3 py-1 rounded-lg text-xs font-medium bg-white/5 text-slate-300 border border-white/10"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:px-8 border-t border-white/10 bg-obsidian-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-obsidian-950 bg-gradient-to-r from-brand-sky to-white hover:from-white hover:to-brand-sky transition-all shadow-md"
          >
            Close Overview
          </button>
        </div>

      </div>
    </div>
  );
};
