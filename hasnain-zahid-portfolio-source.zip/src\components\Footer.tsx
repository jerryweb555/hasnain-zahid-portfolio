import React from 'react';
import { personalInfo } from '../data/portfolioData';
import { 
  ArrowUp, 
  Download, 
  Mail, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  Heart,
  ShieldCheck
} from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { name: 'About Me', href: '#about' },
    { name: 'Experience Timeline', href: '#experience' },
    { name: 'Skills & Capabilities', href: '#skills' },
    { name: 'Certifications', href: '#certificates' },
    { name: 'Education', href: '#education' },
    { name: 'Featured Projects', href: '#projects' },
    { name: 'Services', href: '#services' },
    { name: 'Career Journey', href: '#journey' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <footer className="relative bg-obsidian-950 border-t border-white/10 pt-16 pb-12 overflow-hidden">
      {/* Background soft glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-24 bg-brand-sky/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-14 border-b border-white/10">
          
          {/* Brand Col */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-sky via-brand-indigo to-brand-violet p-[1px] shadow-lg shadow-brand-sky/20">
                <div className="w-full h-full bg-obsidian-900 rounded-[11px] flex items-center justify-center">
                  <span className="font-heading font-extrabold text-base text-transparent bg-clip-text bg-gradient-to-r from-brand-sky to-white">
                    HZ
                  </span>
                </div>
              </div>
              <div>
                <span className="font-heading font-bold text-lg text-white">
                  {personalInfo.name}
                </span>
                <p className="text-xs text-brand-sky">
                  Professional Brand & Digital Portfolio
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Customer Support Specialist, Sales Verification Agent, Digital Marketing Freelancer, and AI Enthusiast. 
              Dedicated to clear communication, high process integrity, and customer trust.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-medium text-emerald-300">
                {personalInfo.status}
              </span>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-4">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4">
              Website Sitemap & Sections
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-slate-400 hover:text-brand-sky transition-colors py-1"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>

          {/* Direct Actions & Download */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Official Documentation
            </h4>
            
            <a
              href={personalInfo.cvUrl}
              download="Hasnain_Zahid_CV.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-semibold text-white bg-obsidian-900 hover:bg-obsidian-800 border border-white/10 hover:border-brand-sky/40 transition-all shadow-sm group"
            >
              <Download className="w-3.5 h-3.5 text-brand-sky group-hover:translate-y-0.5 transition-transform" />
              <span>Download Full CV (PDF)</span>
            </a>

            <div className="p-4 rounded-xl bg-obsidian-900/40 border border-white/5 space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-brand-sky" />
                <span>{personalInfo.location}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-3.5 h-3.5 text-brand-sky" />
                <a href={`mailto:${personalInfo.email}`} className="hover:text-white transition-colors">
                  {personalInfo.email}
                </a>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Phone className="w-3.5 h-3.5 text-brand-sky" />
                <a href={personalInfo.whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  {personalInfo.phone}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} Hasnain Zahid. All rights reserved.</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              100% Authentic Credentials
            </span>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-obsidian-900 hover:bg-obsidian-800 border border-white/10 text-slate-300 hover:text-white transition-all group"
            aria-label="Scroll back to top"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5 text-brand-sky group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

      </div>
    </footer>
  );
};
