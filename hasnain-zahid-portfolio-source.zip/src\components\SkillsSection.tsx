import React, { useState } from 'react';
import { skillCategories } from '../data/portfolioData';
import { 
  CheckCircle2, 
  Sparkles, 
  Headphones, 
  TrendingUp, 
  Compass, 
  Cpu, 
  Search,
  SlidersHorizontal,
  Info
} from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');

  const icons = [Headphones, TrendingUp, Compass, Cpu];

  // Filter skills based on search query
  const currentCategory = skillCategories[activeTab];

  const filteredSkills = searchQuery.trim()
    ? skillCategories.flatMap(cat => 
        cat.skills
          .filter(s => 
            s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
            s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
            s.keywords?.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()))
          )
          .map(s => ({ ...s, categoryName: cat.title }))
      )
    : currentCategory.skills.map(s => ({ ...s, categoryName: currentCategory.title }));

  return (
    <section id="skills" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-violet/10 border border-brand-violet/20 text-brand-violet text-xs font-semibold uppercase tracking-wider mb-4">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              07 — Professional Skills & Capabilities
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Categorized Expertise Across{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-violet via-brand-sky to-white">
                Human & Digital Touchpoints.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">HONEST APPRAISAL</span>
            <p className="text-xs text-slate-400">Ground-tested skills & certified foundations</p>
          </div>
        </div>

        {/* Search Bar & Category Navigation */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-10">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
            {skillCategories.map((cat, idx) => {
              const Icon = icons[idx];
              const isActive = activeTab === idx && !searchQuery.trim();

              return (
                <button
                  key={idx}
                  onClick={() => {
                    setActiveTab(idx);
                    setSearchQuery('');
                  }}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-brand-sky/20 to-brand-indigo/20 text-brand-sky border border-brand-sky/40 shadow-sm'
                      : 'bg-obsidian-900 text-slate-400 hover:text-white border border-white/5 hover:border-white/15'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{cat.title}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Search Input */}
          <div className="relative w-full lg:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search specific skills or tools..."
              className="w-full pl-10 pr-4 py-2 rounded-xl text-xs bg-obsidian-900 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-brand-sky/50 focus:ring-1 focus:ring-brand-sky/50 transition-all"
            />
          </div>

        </div>

        {/* Category Description Banner (when not searching) */}
        {!searchQuery.trim() && (
          <div className="p-6 rounded-2xl bg-obsidian-900/50 border border-white/10 mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-heading font-bold text-lg text-white mb-1">
                {currentCategory.title}
              </h3>
              <p className="text-xs text-slate-400">
                {currentCategory.description}
              </p>
            </div>
            {currentCategory.title.includes('AI') && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 shrink-0">
                <Info className="w-4 h-4 shrink-0" />
                <span>Certified foundational understanding & prompt workflows</span>
              </div>
            )}
          </div>
        )}

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSkills.map((skill, sIdx) => (
            <div
              key={sIdx}
              className="p-6 rounded-2xl glass-card border border-white/10 hover:border-brand-sky/30 transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <h4 className="font-heading font-bold text-base text-white group-hover:text-brand-sky transition-colors">
                    {skill.name}
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wide uppercase shrink-0 bg-white/5 border border-white/10 text-brand-sky">
                    {skill.level}
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-5">
                  {skill.description}
                </p>
              </div>

              {/* Keywords / Tags */}
              {skill.keywords && skill.keywords.length > 0 && (
                <div className="pt-4 border-t border-white/5 flex flex-wrap gap-1.5">
                  {skill.keywords.map((kw, kIdx) => (
                    <span
                      key={kIdx}
                      className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-obsidian-950 text-slate-400 border border-white/5"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
