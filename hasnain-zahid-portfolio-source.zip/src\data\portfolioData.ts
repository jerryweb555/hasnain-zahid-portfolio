import { ExperienceItem, SkillCategory, CertificateItem, EducationItem, ProjectItem, ServiceItem } from '../types';

export const personalInfo = {
  name: 'Hasnain Zahid',
  shortName: 'Hasnain',
  headline: 'Turning Conversations Into Connections, And Ideas Into Digital Experiences.',
  subheading: 'Customer Support Specialist | Sales & Client Communication Professional | Digital Marketing Freelancer | AI Enthusiast',
  email: 'hasnaindc17@gmail.com',
  phone: '0304 7316821',
  phoneInternational: '+92 304 7316821',
  whatsappUrl: 'https://wa.me/923047316821',
  location: 'Ahmed Pur East, Bahawalpur, Pakistan',
  postalCode: '63350',
  cvUrl: '/docs/Hasnain_Zahid_CV.pdf',
  status: 'Open to Roles & Select Consulting Projects',
  bio: `I am a versatile client communication professional who bridges customer-facing excellence with modern digital strategy and AI fluency. My foundation spans real-time outbound customer verification and closing workflows on international campaigns, field-based brand representation, and hands-on freelance consulting for 10+ creator accounts across TikTok and YouTube SEO. With an inquisitive mindset and certified foundations in Generative AI from Google Cloud and Anthropic, I help teams communicate with clarity, empathy, and measurable impact.`,
  languages: [
    { name: 'Urdu', proficiency: 'Native Speaker', level: 100 },
    { name: 'Punjabi', proficiency: 'Upper Intermediate', level: 85 },
    { name: 'English', proficiency: 'Professional Intermediate', level: 75 },
  ],
  stats: [
    { label: 'Client Accounts Guided', value: '10+', detail: 'TikTok creator accounts advised' },
    { label: 'Verified Certifications', value: '4', detail: 'Google Cloud, Anthropic & Udemy' },
    { label: 'Sales & Support Campaigns', value: '3', detail: 'Final Expense & Brand Outreach' },
    { label: 'Client Satisfaction', value: '100%', detail: 'Calm, transparent communication' }
  ]
};

export const experiences: ExperienceItem[] = [
  {
    id: 'exp-tiktok',
    role: 'Customer Support Consultant — TikTok Client Services',
    company: 'Freelance Client Services',
    location: 'Bahawalpur, Pakistan (Remote)',
    type: 'Freelance',
    period: 'May 2025 – March 2026',
    duration: '11 Months',
    category: 'support',
    badgeText: 'Creator Advisory & Support',
    summary: 'Delivered consistent client satisfaction across 10+ creator accounts through calm communication, clear expectation-setting, and content growth consulting.',
    responsibilities: [
      'Supported 10+ content creator accounts with day-to-day communication, inquiries, and growth troubleshooting.',
      'Provided tailored TikTok content strategy guidance focused on audience retention and organic discoverability.',
      'Helped clients understand content growth mechanics, monetization guidelines, and posting cadence.',
      'Maintained consistent customer satisfaction through transparent, empathetic, and responsive messaging.',
      'Managed client expectations professionally under tight deadlines without escalations.'
    ],
    skillsGained: [
      'Client Retention',
      'TikTok Growth Strategy',
      'Account Management',
      'Expectation Setting',
      'Conflict De-escalation'
    ]
  },
  {
    id: 'exp-youtube',
    role: 'Customer Support Consultant — YouTube Client Services',
    company: 'Freelance Client Services',
    location: 'Ahmed Pur East, Pakistan (Remote)',
    type: 'Freelance',
    period: 'September 2025 – January 2026',
    duration: '5 Months',
    category: 'marketing',
    badgeText: 'SEO & Client Discovery',
    summary: 'Managed client communications end-to-end, resolved service concerns, and executed keyword and metadata optimization for improved organic search discoverability.',
    responsibilities: [
      'Managed end-to-end client communications, answering service queries and providing timely status updates.',
      'Resolved service-related questions without needing manager escalation through calm problem-solving.',
      'Conducted targeted keyword research using creator analytics and search intent trends.',
      'Optimized video titles, descriptions, and tags to enhance organic search discoverability and ranking.',
      'Worked collaboratively with channel owners to structure metadata for long-term viewer discovery.'
    ],
    skillsGained: [
      'YouTube SEO',
      'Keyword Research',
      'Metadata Optimization',
      'Client Query Resolution',
      'Organic Search Discovery'
    ]
  },
  {
    id: 'exp-fe-closing',
    role: 'Final Expense Campaign — Closing Experience',
    company: 'International Call Center Campaign',
    location: 'Bahawalpur Region',
    type: 'Campaign / Project',
    period: '3 Months Duration',
    duration: '3 Months',
    category: 'sales',
    badgeText: 'Sales Closing & Negotiation',
    summary: 'Facilitated customer communication during the critical closing stage, addressing objections and establishing trust to support sales conversion.',
    responsibilities: [
      'Handled customer communication during the closing stage of the Final Expense campaign lifecycle.',
      'Listened actively to identify customer priorities, hesitation points, and specific insurance policy requirements.',
      'Conducted professional objection handling with patience, adherence to ethics, and clarity.',
      'Supported the end-to-end sales conversion process alongside team verification leads.',
      'Built genuine customer trust through respectful, authentic, and compliant communication.'
    ],
    skillsGained: [
      'Closing Stage Communication',
      'Objection Handling',
      'Trust Building',
      'Conversion Support',
      'Compliance Adherence'
    ]
  },
  {
    id: 'exp-fe-verification',
    role: 'Final Expense Campaign — Verification Agent',
    company: 'International Call Center Campaign',
    location: 'Bahawalpur Region',
    type: 'Campaign / Project',
    period: '6 Months Duration',
    duration: '6 Months',
    category: 'support',
    badgeText: 'Verification & Quality Assurance',
    summary: 'Conducted rigorous customer verification and information confirmation following standardized campaign protocols and high customer engagement standards.',
    responsibilities: [
      'Conducted real-time customer verification and information confirmation with prospective clients.',
      'Maintained professional, articulate communication with potential customers across diverse backgrounds.',
      'Strictly adhered to campaign operating procedures and regulatory verification workflows.',
      'Exercised active listening to address customer inquiries accurately on initial contact.',
      'Maintained clear, compliant, and structured dialogue to ensure data integrity.'
    ],
    skillsGained: [
      'Information Verification',
      'Workflow Compliance',
      'Active Listening',
      'Quality Assurance',
      'Clear Customer Dialogue'
    ]
  },
  {
    id: 'exp-ptc',
    role: 'Brand Ambassador — PTC Project',
    company: 'PTC Project',
    location: 'Field Campaign',
    type: 'Campaign / Project',
    period: '3 Months Duration',
    duration: '3 Months',
    category: 'ambassador',
    badgeText: 'Field Representation',
    summary: 'Field-based brand representation interacting directly with the public, communicating campaign messaging, and building public engagement confidence.',
    responsibilities: [
      'Represented the project as a field brand ambassador interacting professionally with customers and the public.',
      'Communicated campaign information clearly while maintaining an approachable and positive public presence.',
      'Developed on-the-ground teamwork, interpersonal confidence, and real-time customer handling skills.',
      'Managed field queries smoothly and maintained strict adherence to brand guidelines.',
      'Collaborated closely with campaign field leads to ensure consistent regional reach.'
    ],
    skillsGained: [
      'Field Brand Representation',
      'Public Engagement',
      'Interpersonal Confidence',
      'Teamwork Under Pressure',
      'Brand Advocacy'
    ]
  }
];

export const skillCategories: SkillCategory[] = [
  {
    title: 'Customer Support Excellence',
    description: 'Empathetic, clear, and solution-driven communication built on active listening and calm problem resolution.',
    iconName: 'Headphones',
    skills: [
      {
        name: 'Customer Service',
        level: 'Advanced',
        description: 'Delivering courteous, dependable, and timely assistance across digital and live voice channels.',
        keywords: ['Customer Satisfaction', 'Empathy', 'Responsiveness']
      },
      {
        name: 'Client Query Resolution',
        level: 'Proficient',
        description: 'Diagnosing inquiries accurately and providing step-by-step clarity to eliminate confusion.',
        keywords: ['Troubleshooting', 'De-escalation', 'First Contact Resolution']
      },
      {
        name: 'Complaint Handling',
        level: 'Proficient',
        description: 'Managing difficult customer interactions with a calm demeanor and constructive problem-solving.',
        keywords: ['Patience', 'Empathy', 'Conflict Resolution']
      },
      {
        name: 'Active Listening',
        level: 'Advanced',
        description: 'Listening intently to uncover explicit and implicit customer needs before recommending solutions.',
        keywords: ['Comprehension', 'Clarification', 'Respectful Dialogue']
      },
      {
        name: 'Customer Relationship Management',
        level: 'Proficient',
        description: 'Fostering long-term customer relationships through consistent follow-ups and transparent expectation-setting.',
        keywords: ['CRM Workflows', 'Client Retention', 'Trust Building']
      },
      {
        name: 'Professional Communication',
        level: 'Advanced',
        description: 'Maintaining articulate, grammatically polished, and respectful dialogue across all media.',
        keywords: ['Verbal Fluency', 'Written Precision', 'Professional Tone']
      }
    ]
  },
  {
    title: 'Sales & Conversion Process',
    description: 'Structured verification, consultative objection handling, and relationship-driven closing support.',
    iconName: 'TrendingUp',
    skills: [
      {
        name: 'Lead Verification',
        level: 'Advanced',
        description: 'Cross-checking prospective customer details against campaign guidelines with high accuracy.',
        keywords: ['Data Accuracy', 'Compliance', 'Protocol Adherence']
      },
      {
        name: 'Sales Communication',
        level: 'Proficient',
        description: 'Presenting policy and service value propositions clearly without high-pressure tactics.',
        keywords: ['Value Framing', 'Consultative Dialogue', 'Clarity']
      },
      {
        name: 'Closing Process',
        level: 'Competent',
        description: 'Guiding prospects through final decision-making stages with supportive and reassuring communication.',
        keywords: ['Pipeline Progression', 'Decision Support', 'Follow-through']
      },
      {
        name: 'Objection Handling',
        level: 'Proficient',
        description: 'Addressing hesitation and pricing concerns by refocusing on customer benefits and facts.',
        keywords: ['Reframing', 'Patience', 'Reassurance']
      },
      {
        name: 'Customer Trust Building',
        level: 'Advanced',
        description: 'Cultivating authentic rapport that makes clients feel respected, heard, and protected.',
        keywords: ['Integrity', 'Transparency', 'Rapport']
      }
    ]
  },
  {
    title: 'Digital Marketing & Content Strategy',
    description: 'Data-guided search discoverability, content optimization, and creator audience development.',
    iconName: 'Compass',
    skills: [
      {
        name: 'TikTok Content Strategy',
        level: 'Proficient',
        description: 'Advising creators on hooking retention, trending format adaptation, and monetization guidelines.',
        keywords: ['10+ Accounts', 'Retention Analysis', 'Posting Cadence']
      },
      {
        name: 'YouTube SEO',
        level: 'Proficient',
        description: 'Optimizing video channels for organic YouTube search visibility and algorithmic recommendations.',
        keywords: ['Search Intent', 'Ranking Signals', 'CTR Optimization']
      },
      {
        name: 'Keyword Research',
        level: 'Proficient',
        description: 'Identifying high-volume, low-competition search queries using digital analytics and search behavior.',
        keywords: ['Query Mining', 'Search Volume', 'Intent Mapping']
      },
      {
        name: 'Video Metadata Optimization',
        level: 'Proficient',
        description: 'Structuring titles, descriptions, chapters, and tags to maximize search indexability.',
        keywords: ['Metadata Structuring', 'Tagging Strategy', 'Thumbnails Alignment']
      },
      {
        name: 'Client Consulting',
        level: 'Proficient',
        description: 'Translating complex digital analytics into simple, actionable steps for content creators.',
        keywords: ['Advisory', 'Action Plans', 'Strategy Sessions']
      }
    ]
  },
  {
    title: 'AI Fluency & Modern Technology',
    description: 'Certified foundational understanding of Generative AI principles, prompt workflows, and practical applications.',
    iconName: 'Cpu',
    skills: [
      {
        name: 'Generative AI Fundamentals',
        level: 'Certified Foundation',
        description: 'Certified grasp of large language models, training paradigms, and foundational concepts via Google Cloud.',
        keywords: ['Google Cloud Certified', 'LLM Concepts', 'Responsible AI']
      },
      {
        name: 'AI Fluency & Frameworks',
        level: 'Certified Foundation',
        description: 'Understanding core AI frameworks, capability evaluation, and ethical considerations via Anthropic Education.',
        keywords: ['Anthropic Certified', 'AI Capabilities', 'Foundations']
      },
      {
        name: 'AI Tools & Daily Workflows',
        level: 'Practical User',
        description: 'Leveraging modern AI assistants for research, drafting, customer correspondence, and idea generation.',
        keywords: ['Workflow Acceleration', 'Prompt Crafting', 'Productivity']
      },
      {
        name: 'Modern AI Applications',
        level: 'Working Knowledge',
        description: 'Awareness of customer support AI agents, retrieval pipelines, and conversational interfaces.',
        keywords: ['AI Support Systems', 'Human-in-the-Loop', 'Use Cases']
      }
    ]
  }
];

export const certifications: CertificateItem[] = [
  {
    id: 'cert-google-genai',
    title: 'Introduction to Generative AI',
    issuer: 'Google Cloud',
    date: 'Certified 2026',
    badgeType: 'Completion Badge',
    fileUrl: '/certificates/google-genai-badge.png',
    fileType: 'image',
    previewImageUrl: '/certificates/google-genai-badge.png',
    description: 'Official Google Cloud completion badge demonstrating foundational understanding of Generative AI concepts, how LLMs work, and principles of responsible AI development.',
    skillsHighlighted: ['Generative AI Concepts', 'Large Language Models', 'Responsible AI Practices'],
    featured: true
  },
  {
    id: 'cert-anthropic-fluency',
    title: 'AI Fluency: Framework & Foundations',
    issuer: 'Anthropic',
    date: 'August 8, 2026',
    badgeType: 'Certificate of Completion',
    fileUrl: '/certificates/anthropic-ai-fluency.pdf',
    fileType: 'pdf',
    description: 'Official Anthropic Education certificate verifying completion of the AI Fluency curriculum covering foundational frameworks, AI system capabilities, safety principles, and modern applications.',
    skillsHighlighted: ['AI Fluency Framework', 'Model Strengths & Limitations', 'AI Application Concepts'],
    featured: true
  },
  {
    id: 'cert-udemy-truck',
    title: 'USA Truck Dispatcher Full Course',
    issuer: 'Udemy',
    instructor: 'Dmitry Demishev',
    date: 'September 3, 2026',
    duration: '8 total hours',
    credentialId: 'UC-55505e39-f280-4460-ac91-5697527c2ed6',
    verifyUrl: 'https://ude.my/UC-55505e39-f280-4460-ac91-5697527c2ed6',
    badgeType: 'Certificate of Completion',
    fileUrl: '/certificates/udemy-truck-dispatcher.pdf',
    fileType: 'pdf',
    description: 'Comprehensive 8-hour training course covering logistics dispatching, route planning, driver communication, freight negotiations, and logistics workflows in the US transportation sector.',
    skillsHighlighted: ['Dispatch Operations', 'Carrier Communication', 'Logistics Workflow', 'Negotiation Basics'],
    featured: true
  },
  {
    id: 'cert-udemy-callcenter',
    title: 'Getting Started with Call Center Training',
    issuer: 'Udemy',
    instructor: 'Sinan Cetiner',
    date: 'August 14, 2026',
    duration: '1 total hour',
    credentialId: 'UC-510343d2-6638-4def-b754-3af781796304',
    verifyUrl: 'https://ude.my/UC-510343d2-6638-4def-b754-3af781796304',
    badgeType: 'Certificate of Completion',
    fileUrl: '/certificates/udemy-call-center.pdf',
    fileType: 'pdf',
    description: 'Structured industry training on call center operational etiquette, customer service standards, telephony protocols, active inquiry handling, and professional phone engagement.',
    skillsHighlighted: ['Call Center Etiquette', 'Inquiry Handling', 'Professional Telephony', 'Customer Care Standards'],
    featured: true
  }
];

export const educationList: EducationItem[] = [
  {
    degree: 'Intermediate in Computer Science (ICS)',
    field: 'Computer Science, Mathematics & Statistics',
    institution: 'Govt. Sadiq Abbas College',
    boardOrAuthority: 'BISE Bahawalpur',
    period: 'August 2025 – August 2027',
    status: 'Currently Pursuing (Part 1 completed, Part 2 in progress)',
    highlights: [
      'Comprehensive coursework in computer fundamentals, programming logic, and computational thinking.',
      'Active student with consistent attendance and focus on software applications and modern AI.',
      'Balancing academic excellence with real-world freelance client communication projects.'
    ]
  },
  {
    degree: 'Matriculation (Secondary School Certificate)',
    field: 'Computer Science Group',
    institution: 'Sadiq Abbas Public School, Ahmed Pur East',
    boardOrAuthority: 'BISE Bahawalpur',
    period: 'March 2023 – March 2025',
    status: 'Completed (2025)',
    gradeOrMarks: '779 / 1200 (65%)',
    highlights: [
      'Established foundational knowledge in computer hardware, basic programming concepts, and mathematics.',
      'Demonstrated disciplined work ethic and interest in digital communications.',
      'Successfully graduated in the Computer Science discipline.'
    ]
  }
];

export const projectsList: ProjectItem[] = [
  {
    id: 'proj-brightsmile',
    title: 'BrightSmile Dental AI Assistant',
    category: 'AI Prototype',
    badge: 'Demonstration Prototype',
    shortDesc: 'AI customer support and lead management prototype designed for 24/7 dental patient inquiry handling and appointment booking.',
    fullDesc: 'A concept demonstration showcasing how conversational AI and structured prompt workflows can assist clinical practices in handling after-hours inquiries, qualifying emergency appointments, and collecting structured patient intake data without overwhelming front-desk staff.',
    problem: 'Healthcare and dental clinics often lose patient leads during off-hours, and front-desk receptionists are frequently overloaded with repetitive scheduling and insurance qualification questions.',
    solution: 'Designed an interactive conversational prototype featuring compassionate triage prompts, automated FAQs for common procedures, and structured lead capture forms that hand off seamlessly to human staff.',
    keyOutcomes: [
      'Simulated 24/7 patient inquiry handling with calm, polite tone guidelines',
      'Demonstrated structured question-flow for insurance verification readiness',
      'Created clear escalation paths to human reception for medical emergencies'
    ],
    techOrTools: ['Conversational Prompt Engineering', 'Google Cloud GenAI Concepts', 'Workflow Logic', 'UI Prototype'],
    isDemoPrototype: true
  },
  {
    id: 'proj-youtube-seo',
    title: 'YouTube SEO & Discoverability Showcase',
    category: 'SEO Case Study',
    badge: 'Client Consulting Case Study',
    shortDesc: 'Strategic keyword research, title restructuring, and metadata optimization across creator channels to increase organic search reach.',
    fullDesc: 'A comprehensive methodology applied across freelance client channels to turn overlooked videos into recurring search traffic drivers through semantic title design, description search indexing, and tag taxonomy.',
    problem: 'Creators produce high-quality video content that remains undiscovered due to weak keyword alignment, vague video titles, and unoptimized metadata.',
    solution: 'Audited existing video libraries, conducted competition query research, and overhauled titles to combine search intent keywords with high-CTR curiosity hooks, paired with timestamp chapters and structured descriptions.',
    keyOutcomes: [
      'Formulated structured metadata templates adopted across multiple client channels',
      'Improved video discoverability across YouTube Search and Suggested browse features',
      'Maintained zero escalations with clients through transparent weekly progress summaries'
    ],
    techOrTools: ['YouTube Studio', 'Keyword Intent Analysis', 'Metadata Taxonomy', 'Client Communication'],
    isDemoPrototype: false
  },
  {
    id: 'proj-tiktok-consulting',
    title: 'TikTok Creator Growth & Client Advisory',
    category: 'Creator Consulting',
    badge: 'Client Consulting Case Study',
    shortDesc: 'One-on-one consulting and customer support for 10+ creator accounts, providing content strategy guidance and expectation management.',
    fullDesc: 'End-to-end client service consulting for content creators, advising on audience retention tactics, sound trend integration, posting consistency, and navigation of creator monetization policies.',
    problem: 'New and growing creators face sudden algorithmic shifts, confusion around monetization eligibility, and lack structured advice on maintaining audience retention.',
    solution: 'Provided continuous support through personalized guidance messages, content breakdown sessions, and structured feedback on the first 3 seconds of video hooks.',
    keyOutcomes: [
      'Delivered dedicated support to 10+ creator accounts with high client satisfaction',
      'Guided creators through video structure improvements to boost average watch time',
      'Maintained calm, reassuring customer support through tight deadlines and algorithm changes'
    ],
    techOrTools: ['TikTok Analytics', 'Content Structure Review', 'Client Support CRM', 'Retention Strategy'],
    isDemoPrototype: false
  }
];

export const servicesList: ServiceItem[] = [
  {
    id: 'srv-support',
    title: 'Customer Support & Query Care',
    subtitle: 'Calm, Empathetic, First-Contact Resolution',
    description: 'Dedicated customer communication that turns frustrated inquiries into loyal brand advocates through active listening and rapid, articulate problem resolution.',
    deliverables: [
      'Inbound customer query handling via email, chat, or voice',
      'De-escalation and professional complaint management',
      'CRM ticket documentation and structured customer follow-ups',
      'Strict adherence to client brand voice and service standards'
    ],
    icon: 'Headset',
    category: 'Customer Care'
  },
  {
    id: 'srv-sales',
    title: 'Lead Verification & Sales Support',
    subtitle: 'High-Integrity Verification & Trust-Building',
    description: 'Structured outbound and inbound customer verification that confirms prospect qualifications, answers questions transparently, and supports sales conversions.',
    deliverables: [
      'Accurate customer verification workflows & data confirmation',
      'Consultative objection handling without aggressive pressure',
      'Support during closing conversations to build buyer confidence',
      'Thorough compliance tracking and workflow integrity'
    ],
    icon: 'CheckCircle2',
    category: 'Sales Operations'
  },
  {
    id: 'srv-youtube',
    title: 'YouTube Video SEO & Metadata',
    subtitle: 'Organic Reach & Search Indexing Optimization',
    description: 'Transforming video libraries into searchable digital assets through keyword research, high-CTR titles, and structured metadata architecture.',
    deliverables: [
      'In-depth search intent and keyword competition research',
      'High-CTR title formulation balancing SEO and human curiosity',
      'Complete metadata overhaul (Descriptions, Tags, Chapters)',
      'Channel discoverability audit and practical action plan'
    ],
    icon: 'Youtube',
    category: 'Digital Marketing'
  },
  {
    id: 'srv-tiktok',
    title: 'TikTok Strategy & Creator Advisory',
    subtitle: 'Audience Retention & Content Growth Guidance',
    description: 'Practical, hands-on advisory for creators looking to understand algorithmic trends, improve retention hooks, and navigate monetization milestones.',
    deliverables: [
      'Video hook and watch-time retention evaluation',
      'Posting cadence and content pillar strategy recommendations',
      'Monetization guidance and policy compliance clarity',
      'Direct, responsive client support for creator troubleshooting'
    ],
    icon: 'Video',
    category: 'Creator Advisory'
  },
  {
    id: 'srv-ai',
    title: 'AI Workflow Exploration',
    subtitle: 'Certified Foundational AI Integration',
    description: 'Helping small teams and creators leverage modern AI tools to accelerate research, draft correspondence, and streamline customer communication workflows.',
    deliverables: [
      'Prompt structuring for customer service canned responses',
      'Exploration of generative AI tools for productivity acceleration',
      'Practical evaluation of AI capabilities and limitations',
      'Foundational guidance aligned with Google Cloud & Anthropic frameworks'
    ],
    icon: 'Sparkles',
    category: 'Technology & AI'
  }
];

export const journeyMilestones = [
  {
    phase: 'Foundations & Discipline',
    timeframe: '2023 – 2025',
    headline: 'Academic Grounding in Computer Science & Public Engagement',
    description: 'Graduated Matriculation in Computer Science with 65%, followed by field representation as a Brand Ambassador for the PTC Project, building foundational public communication, teamwork, and resilience under real-world conditions.'
  },
  {
    phase: 'High-Stakes Communication',
    timeframe: '2025 – 2026',
    headline: 'International Call Center Verification & Sales Closing',
    description: 'Immersed in high-paced verification and closing roles for the Final Expense campaign. Mastered active listening, strict procedural compliance, objection reframing, and customer trust-building across 9 months of intense live customer dialogue.'
  },
  {
    phase: 'Digital Freelancing & Creator Advisory',
    timeframe: '2025 – 2026',
    headline: 'TikTok Strategy for 10+ Accounts & YouTube SEO',
    description: 'Expanded into digital marketing freelancing, consulting with 10+ creator accounts on TikTok growth strategy while optimizing YouTube video metadata for search discoverability. Maintained 100% calm, escalations-free customer satisfaction.'
  },
  {
    phase: 'AI Fluency & Future Horizons',
    timeframe: '2026 & Beyond',
    headline: 'Certified AI Foundations & Intermediate Studies',
    description: 'Pursuing Intermediate in Computer Science at Govt. Sadiq Abbas College while earning official credentials from Google Cloud (Generative AI) and Anthropic (AI Fluency Framework). Blending human empathy with modern technological literacy.'
  }
];
