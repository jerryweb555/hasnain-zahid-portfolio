import React, { useState } from 'react';
import { personalInfo } from '../data/portfolioData';
import { 
  Mail, 
  Phone, 
  Send, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Copy, 
  Check, 
  ExternalLink,
  MapPin,
  Clock,
  ArrowRight
} from 'lucide-react';

interface FormState {
  name: string;
  email: string;
  inquiryType: string;
  subject: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState<FormState>({
    name: '',
    email: '',
    inquiryType: 'Customer Support Opportunity',
    subject: '',
    message: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedStatus, setSubmittedStatus] = useState<null | {
    type: 'success';
    mailtoUrl: string;
    waUrl: string;
  }>(null);

  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your name or organization.';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Name should be at least 2 characters.';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide a contact email address.';
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email format (e.g. name@domain.com).';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Please specify an inquiry subject.';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Please include details about your inquiry.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) {
      return;
    }

    // Build mailto URL with properly encoded fields
    const bodyContent = `Name: ${formData.name}\nEmail: ${formData.email}\nInquiry Type: ${formData.inquiryType}\n\nMessage:\n${formData.message}`;
    const mailto = `mailto:${personalInfo.email}?subject=${encodeURIComponent(
      `[${formData.inquiryType}] ${formData.subject}`
    )}&body=${encodeURIComponent(bodyContent)}`;

    // Build WhatsApp URL
    const waText = `Hi Hasnain, my name is ${formData.name}. Regarding ${formData.subject} (${formData.inquiryType}):\n\n${formData.message}`;
    const waUrl = `https://wa.me/923047316821?text=${encodeURIComponent(waText)}`;

    // Set submitted state with direct links without pretending backend received it
    setSubmittedStatus({
      type: 'success',
      mailtoUrl: mailto,
      waUrl: waUrl
    });

    // Attempt to trigger mailto
    window.location.href = mailto;
  };

  const handleCopy = (text: string, type: 'email' | 'phone') => {
    navigator.clipboard.writeText(text);
    if (type === 'email') {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } else {
      setCopiedPhone(true);
      setTimeout(() => setCopiedPhone(false), 2000);
    }
  };

  return (
    <section id="contact" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-sky/10 border border-brand-sky/20 text-brand-sky text-xs font-semibold uppercase tracking-wider mb-4">
              <MessageSquare className="w-3.5 h-3.5" />
              13 — Contact & Professional Connection
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Let's Connect & Discuss Your{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-cyan-300 to-white">
                Team or Project Needs.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">DIRECT REACH</span>
            <p className="text-xs text-slate-400">Response within 24 business hours</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Contact Details & Availability */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Quick Contact Card */}
            <div className="p-8 rounded-3xl glass-card border border-white/10 shadow-2xl space-y-6">
              <div>
                <h3 className="font-heading font-bold text-xl text-white mb-2">
                  Direct Communications
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Available for full-time customer support positions, sales verification contracts, 
                  call center roles, and creator consulting projects.
                </p>
              </div>

              {/* Direct Email */}
              <div className="p-4 rounded-2xl bg-obsidian-900/80 border border-white/5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-sky/15 border border-brand-sky/30 flex items-center justify-center text-brand-sky shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-mono text-slate-500 uppercase">Direct Email</span>
                    <a
                      href={`mailto:${personalInfo.email}`}
                      className="text-xs font-semibold text-white hover:text-brand-sky block transition-colors"
                    >
                      {personalInfo.email}
                    </a>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(personalInfo.email, 'email')}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                  title="Copy Email Address"
                >
                  {copiedEmail ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Direct Phone / WhatsApp */}
              <div className="p-4 rounded-2xl bg-obsidian-900/80 border border-white/5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-mono text-slate-500 uppercase">Phone & WhatsApp</span>
                    <a
                      href={personalInfo.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-white hover:text-emerald-400 block transition-colors"
                    >
                      {personalInfo.phone}
                    </a>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(personalInfo.phone, 'phone')}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                  title="Copy Phone Number"
                >
                  {copiedPhone ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Location & Timezone */}
              <div className="p-4 rounded-2xl bg-obsidian-900/80 border border-white/5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-indigo/15 border border-brand-indigo/30 flex items-center justify-center text-brand-indigo shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-mono text-slate-500 uppercase">Primary Location</span>
                  <p className="text-xs font-semibold text-white">
                    {personalInfo.location} (PKT, UTC+5)
                  </p>
                </div>
              </div>

              {/* Fast WhatsApp Chat Button */}
              <a
                href={personalInfo.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-semibold text-xs border border-emerald-500/30 transition-all shadow-sm group"
              >
                <span>Message Instantly on WhatsApp</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

            </div>

            {/* LinkedIn Profile Placeholder */}
            <div className="p-5 rounded-2xl bg-obsidian-900/50 border border-white/5 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-white block">Professional LinkedIn</span>
                <span className="text-[11px] text-slate-400">Available upon direct request / hiring stage</span>
              </div>
              <span className="px-2.5 py-1 rounded-md text-[10px] font-mono bg-white/5 text-slate-400 border border-white/5">
                Verified
              </span>
            </div>

          </div>

          {/* Right Column: Validated Professional Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-3xl glass-card border border-white/10 shadow-2xl relative">
              <h3 className="font-heading font-bold text-2xl text-white mb-2">
                Send a Professional Inquiry
              </h3>
              <p className="text-xs text-slate-400 mb-8 leading-relaxed">
                Fill in the details below. This form validates your message and provides immediate 
                dispatch options via your preferred mail client or WhatsApp.
              </p>

              {/* Status Message / Confirmation */}
              {submittedStatus && (
                <div className="mb-8 p-5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-200 space-y-3 animate-in fade-in">
                  <div className="flex items-center gap-2 text-emerald-300 font-semibold">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span>Inquiry Formatted & Prepared!</span>
                  </div>
                  <p className="leading-relaxed text-slate-300">
                    Your message has been organized with your contact details. Because this website runs 
                    without a remote email server, your default email client should have opened automatically. 
                    If it didn't, click below to open your email or send via WhatsApp:
                  </p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    <a
                      href={submittedStatus.mailtoUrl}
                      className="px-4 py-2 rounded-xl bg-white text-obsidian-950 font-semibold text-xs inline-flex items-center gap-1.5"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      Open in Email App
                    </a>
                    <a
                      href={submittedStatus.waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-xl bg-emerald-500 text-obsidian-950 font-semibold text-xs inline-flex items-center gap-1.5"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      Dispatch via WhatsApp
                    </a>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                {/* Name & Email Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Your Name / Company <span className="text-brand-sky">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        if (errors.name) setErrors({ ...errors, name: undefined });
                      }}
                      placeholder="e.g. John Doe / Hiring Lead"
                      className={`w-full px-4 py-3 rounded-xl bg-obsidian-950/80 border text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                        errors.name
                          ? 'border-rose-500/80 focus:ring-1 focus:ring-rose-500'
                          : 'border-white/10 focus:border-brand-sky/60 focus:ring-1 focus:ring-brand-sky/40'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-[11px] text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.name}
                      </p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Email Address <span className="text-brand-sky">*</span>
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => {
                        setFormData({ ...formData, email: e.target.value });
                        if (errors.email) setErrors({ ...errors, email: undefined });
                      }}
                      placeholder="name@company.com"
                      className={`w-full px-4 py-3 rounded-xl bg-obsidian-950/80 border text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                        errors.email
                          ? 'border-rose-500/80 focus:ring-1 focus:ring-rose-500'
                          : 'border-white/10 focus:border-brand-sky/60 focus:ring-1 focus:ring-brand-sky/40'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-[11px] text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.email}
                      </p>
                    )}
                  </div>
                </div>

                {/* Inquiry Type & Subject */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Inquiry Category
                    </label>
                    <select
                      value={formData.inquiryType}
                      onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-obsidian-950/80 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-sky/60 focus:ring-1 focus:ring-brand-sky/40 transition-all"
                    >
                      <option value="Customer Support Opportunity">Customer Support Opportunity</option>
                      <option value="Sales Verification / Closing Role">Sales Verification / Closing Role</option>
                      <option value="TikTok & Creator Consulting">TikTok & Creator Consulting</option>
                      <option value="YouTube SEO Project">YouTube SEO Project</option>
                      <option value="General Professional Connection">General Professional Connection</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Subject <span className="text-brand-sky">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => {
                        setFormData({ ...formData, subject: e.target.value });
                        if (errors.subject) setErrors({ ...errors, subject: undefined });
                      }}
                      placeholder="Brief topic of discussion"
                      className={`w-full px-4 py-3 rounded-xl bg-obsidian-950/80 border text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                        errors.subject
                          ? 'border-rose-500/80 focus:ring-1 focus:ring-rose-500'
                          : 'border-white/10 focus:border-brand-sky/60 focus:ring-1 focus:ring-brand-sky/40'
                      }`}
                    />
                    {errors.subject && (
                      <p className="text-[11px] text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.subject}
                      </p>
                    )}
                  </div>
                </div>

                {/* Message Body */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Message Details <span className="text-brand-sky">*</span>
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => {
                      setFormData({ ...formData, message: e.target.value });
                      if (errors.message) setErrors({ ...errors, message: undefined });
                    }}
                    placeholder="Provide context regarding the position, project scope, or questions..."
                    className={`w-full px-4 py-3 rounded-xl bg-obsidian-950/80 border text-xs text-white placeholder-slate-500 focus:outline-none transition-all resize-none ${
                      errors.message
                        ? 'border-rose-500/80 focus:ring-1 focus:ring-rose-500'
                        : 'border-white/10 focus:border-brand-sky/60 focus:ring-1 focus:ring-brand-sky/40'
                    }`}
                  />
                  {errors.message && (
                    <p className="text-[11px] text-rose-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {errors.message}
                    </p>
                  )}
                </div>

                {/* Submit Action */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl font-semibold text-xs text-obsidian-950 bg-gradient-to-r from-brand-sky via-cyan-300 to-white hover:from-white hover:to-brand-sky transition-all duration-300 shadow-lg shadow-brand-sky/25 hover:shadow-brand-sky/40 group"
                  >
                    <Send className="w-4 h-4 text-obsidian-950 group-hover:translate-x-0.5 transition-transform" />
                    <span>Validate & Dispatch Inquiry</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
