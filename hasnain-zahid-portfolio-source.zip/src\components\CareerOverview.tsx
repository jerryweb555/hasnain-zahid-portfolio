import React from 'react';
import { 
  BarChart3, 
  Users, 
  Award, 
  PhoneIncoming, 
  CheckCircle2, 
  ShieldCheck
} from 'lucide-react';

export const CareerOverview: React.FC = () => {
  const metrics = [
    {
      title: 'Creator Accounts Guided',
      value: '10+',
      metricNote: 'TikTok Client Services',
      description: 'Supported individual creators with organic posting strategies, hook retention, and monetization policy guidelines.',
      icon: Users,
      accent: 'text-brand-sky',
      bgAccent: 'bg-brand-sky/10 border-brand-sky/20'
    },
    {
      title: 'Call Center Experience',
      value: '9 Mos',
      metricNote: '6M Verification + 3M Closing',
      description: 'Frontline telephonic verification and closing for the Final Expense campaign adhering strictly to SOPs.',
      icon: PhoneIncoming,
      accent: 'text-emerald-400',
      bgAccent: 'bg-emerald-500/10 border-emerald-500/20'
    },
    {
      title: 'Certified Credentials',
      value: '4',
      metricNote: 'Google Cloud, Anthropic, Udemy',
      description: 'Official completions in Generative AI, AI Fluency, US Truck Dispatching, and Call Center Operations.',
      icon: Award,
      accent: 'text-indigo-400',
      bgAccent: 'bg-indigo-500/10 border-indigo-500/20'
    },
    {
      title: 'Client Satisfaction',
      value: '100%',
      metricNote: 'No Escalations',
      description: 'Maintained calm, transparent, and prompt expectation-setting across all freelance and campaign touchpoints.',
      icon: ShieldCheck,
      accent: 'text-amber-400',
      bgAccent: 'bg-amber-500/10 border-amber-500/20'
    }
  ];

  return (
    <section id="overview" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-4">
              <BarChart3 className="w-3.5 h-3.5" />
              05 — Career Overview & Milestones
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Verified Experience Backed By{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-brand-sky to-white">
                Demonstrated Commitment.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">TRANSPARENCY STANDARD</span>
            <p className="text-xs text-slate-400">Strictly authentic data without inflated figures</p>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {metrics.map((m, idx) => {
            const Icon = m.icon;
            return (
              <div
                key={idx}
                className="relative p-7 rounded-3xl glass-card border border-white/10 hover:border-white/20 transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="flex items-center justify-between mb-5">
                  <div className={`w-12 h-12 rounded-2xl ${m.bgAccent} border flex items-center justify-center ${m.accent} group-hover:scale-108 transition-transform`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-mono text-slate-500">REF-{idx + 1}</span>
                </div>

                <div className="mb-2">
                  <span className="font-heading font-black text-4xl text-white tracking-tight">
                    {m.value}
                  </span>
                  <div className="text-xs font-medium text-brand-sky mt-1">
                    {m.metricNote}
                  </div>
                </div>

                <h3 className="font-heading font-bold text-base text-slate-200 mb-2">
                  {m.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {m.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Professional Core Competencies Matrix */}
        <div className="p-8 sm:p-10 rounded-3xl bg-obsidian-900/80 border border-white/10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div className="space-y-3">
              <span className="text-xs font-mono text-brand-sky uppercase tracking-wider">DOMAIN 01</span>
              <h4 className="font-heading font-bold text-xl text-white">Call Center & Customer Support</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Specialized in high-volume phone communication, inbound/outbound customer inquiry handling, objection reframing, and rigorous procedural compliance.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Active listening and query clarification
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Complaint de-escalation & calm demeanor
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> CRM and workflow data integrity
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider">DOMAIN 02</span>
              <h4 className="font-heading font-bold text-xl text-white">Sales Closing & Verification</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Trained in the structured sales pipeline for US Final Expense insurance, verifying critical client information and building buyer trust during closing.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Rigorous customer qualification check
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Ethical, trust-first objection resolution
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Seamless handoff between agents
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <span className="text-xs font-mono text-indigo-400 uppercase tracking-wider">DOMAIN 03</span>
              <h4 className="font-heading font-bold text-xl text-white">Digital Strategy & AI Fluency</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Pairing practical digital marketing freelancing (YouTube SEO, TikTok growth) with certified foundation understanding of modern Generative AI models.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Keyword taxonomy & YouTube metadata
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> TikTok audience retention evaluation
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Certified AI literacy (Google Cloud & Anthropic)
                </li>
              </ul>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
