import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { IntroSection } from './components/IntroSection';
import { AboutSection } from './components/AboutSection';
import { CareerOverview } from './components/CareerOverview';
import { ExperienceTimeline } from './components/ExperienceTimeline';
import { SkillsSection } from './components/SkillsSection';
import { CertificatesSection } from './components/CertificatesSection';
import { EducationSection } from './components/EducationSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ServicesSection } from './components/ServicesSection';
import { JourneySection } from './components/JourneySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-obsidian-950 text-slate-100 flex flex-col selection:bg-brand-sky/25 selection:text-brand-sky">
      {/* 01 — Premium Navigation */}
      <Navbar />

      <main className="flex-1">
        {/* 02 — Immersive 3D Hero */}
        <Hero />

        {/* 03 — Professional Introduction */}
        <IntroSection />

        {/* 04 — About Me */}
        <AboutSection />

        {/* 05 — Career Overview */}
        <CareerOverview />

        {/* 06 — Professional Experience Timeline */}
        <ExperienceTimeline />

        {/* 07 — Skills & Expertise */}
        <SkillsSection />

        {/* 08 — Certifications & Credentials */}
        <CertificatesSection />

        {/* 09 — Education */}
        <EducationSection />

        {/* 10 — Featured Projects */}
        <ProjectsSection />

        {/* 11 — Services */}
        <ServicesSection />

        {/* 12 — Professional Journey */}
        <JourneySection />

        {/* 13 — Contact Section */}
        <ContactSection />
      </main>

      {/* 14 — Premium Footer */}
      <Footer />
    </div>
  );
};

export default App;
