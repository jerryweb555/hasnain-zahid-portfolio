import React from 'react';
import { personalInfo } from '../data/portfolioData';
import { 
  User, 
  MapPin, 
  Languages, 
  HeartHandshake, 
  Download, 
  Mail, 
  Phone, 
  Clock,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 relative bg-obsidian-900/60 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-indigo/10 border border-brand-indigo/20 text-brand-indigo text-xs font-semibold uppercase tracking-wider mb-4">
            <User className="w-3.5 h-3.5 text-brand-indigo" />
            04 — About Me
          </div>
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
            Clear Communication, Dependable Work Ethic, & a{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-cyan-300 to-white">
              Growth Mindset.
            </span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Visual Bio Card & Quick Contact Chips */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Persona Glass Box */}
            <div className="p-8 rounded-3xl glass-card border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-brand-sky/10 rounded-full blur-2xl pointer-events-none" />

              {/* Avatar Initial Art */}
              <div className="flex items-center gap-5 mb-6">
                <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-brand-sky via-brand-indigo to-brand-violet p-[2px] shadow-xl shadow-brand-sky/20">
                  <div className="w-full h-full bg-obsidian-950 rounded-[14px] flex flex-col items-center justify-center">
                    <span className="font-heading font-black text-2xl text-transparent bg-clip-text bg-gradient-to-r from-brand-sky to-white">
                      HZ
                    </span>
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                      PRO
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="font-heading font-bold text-2xl text-white">
                    {personalInfo.name}
                  </h3>
                  <p className="text-xs text-brand-sky font-medium">
                    Customer Support & Sales Professional
                  </p>
                  <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-400">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    <span>{personalInfo.location}</span>
                  </div>
                </div>
              </div>

              {/* Bio Narrative */}
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                Known for a calm, attentive, and customer-centered disposition, I bridge interpersonal 
                communication and digital workflows. Whether clarifying complex policy terms for prospective 
                clients or helping digital creators optimize content cadence, I prioritize clarity and genuine accountability.
              </p>

              {/* Verified Contact Details Grid */}
              <div className="space-y-3 pt-6 border-t border-white/10 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-brand-sky" /> Email:
                  </span>
                  <a href={`mailto:${personalInfo.email}`} className="font-mono text-white hover:text-brand-sky transition-colors">
                    {personalInfo.email}
                  </a>
                </div>

                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-brand-sky" /> Phone / WhatsApp:
                  </span>
                  <a href={personalInfo.whatsappUrl} target="_blank" rel="noopener noreferrer" className="font-mono text-white hover:text-brand-sky transition-colors">
                    {personalInfo.phone}
                  </a>
                </div>

                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-brand-sky" /> Availability:
                  </span>
                  <span className="text-emerald-400 font-medium flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Immediate / Flexible
                  </span>
                </div>
              </div>

              {/* CV Action */}
              <div className="mt-6 pt-6 border-t border-white/10 flex gap-3">
                <a
                  href={personalInfo.cvUrl}
                  download="Hasnain_Zahid_CV.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold border border-white/10 hover:border-white/20 transition-all shadow-sm"
                >
                  <Download className="w-3.5 h-3.5 text-brand-sky" />
                  Download Official CV (PDF)
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Values & Linguistic Fluency */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Core Philosophy Statement */}
            <div className="p-8 rounded-3xl bg-obsidian-950/80 border border-white/10">
              <h4 className="font-heading font-bold text-xl text-white mb-4 flex items-center gap-2.5">
                <HeartHandshake className="w-5 h-5 text-brand-sky" />
                Communication Philosophy & Work Ethics
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                Customer support is not just answering tickets or following scripts—it is de-escalating customer anxiety, 
                establishing mutual respect, and creating clarity. During my time on high-demand campaigns, I proved 
                that calm dialogue and active listening build far greater rapport than aggressive pitching.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-obsidian-900/60 border border-white/5">
                  <div className="text-xs font-bold text-white mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Authenticity & Compliance
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Always adhering to campaign guidelines, privacy regulations, and honest customer representation.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-obsidian-900/60 border border-white/5">
                  <div className="text-xs font-bold text-white mb-1 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-brand-sky" />
                    Tech-Enabled Efficiency
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Utilizing Generative AI assistants to draft clear correspondence, summarize findings, and boost daily productivity.
                  </p>
                </div>
              </div>
            </div>

            {/* Language Fluency Section */}
            <div className="p-8 rounded-3xl bg-obsidian-950/80 border border-white/10">
              <div className="flex items-center justify-between mb-6">
                <h4 className="font-heading font-bold text-xl text-white flex items-center gap-2.5">
                  <Languages className="w-5 h-5 text-brand-indigo" />
                  Language Capabilities & Fluency
                </h4>
                <span className="text-xs font-mono text-slate-400">Trilingual Profile</span>
              </div>

              <div className="space-y-5">
                {personalInfo.languages.map((lang, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-white tracking-wide">
                        {lang.name}
                      </span>
                      <span className="text-slate-400 font-mono">
                        {lang.proficiency}
                      </span>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full h-2 rounded-full bg-obsidian-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-brand-sky to-brand-indigo transition-all duration-1000"
                        style={{ width: `${lang.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-[11px] text-slate-400 mt-5 pt-4 border-t border-white/5 leading-relaxed">
                Comfortable communicating across regional Pakistani dialects (Urdu and Punjabi) as well as conducting professional English correspondence for overseas campaigns and digital clients.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
