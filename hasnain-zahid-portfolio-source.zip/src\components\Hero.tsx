import React, { useEffect, useRef } from 'react';
import { personalInfo } from '../data/portfolioData';
import { Hero3D } from './Hero3D';
import { 
  ArrowRight, 
  Award, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  MapPin, 
  ShieldCheck, 
  Briefcase 
} from 'lucide-react';
import gsap from 'gsap';

export const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // GSAP entrance sequence
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      tl.from(badgeRef.current, {
        opacity: 0,
        y: -20,
        duration: 0.8,
        delay: 0.2,
      })
      .from(headlineRef.current, {
        opacity: 0,
        y: 30,
        duration: 1,
      }, '-=0.5')
      .from(subRef.current, {
        opacity: 0,
        y: 20,
        duration: 0.8,
      }, '-=0.6')
      .from(ctaRef.current, {
        opacity: 0,
        y: 20,
        duration: 0.8,
      }, '-=0.5')
      .from(statsRef.current, {
        opacity: 0,
        y: 20,
        duration: 0.8,
      }, '-=0.5');
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen pt-28 pb-16 lg:pt-36 lg:pb-24 flex items-center justify-center overflow-hidden bg-radial-hero bg-grid-pattern"
    >
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-brand-sky/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-brand-indigo/10 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Brand & Hero Copy */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-20">
            
            {/* Status & Identity Badge */}
            <div
              ref={badgeRef}
              className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-obsidian-900/80 border border-white/10 backdrop-blur-md shadow-sm mb-6"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="text-xs font-medium text-slate-300">
                {personalInfo.name} — Personal Portfolio
              </span>
              <span className="text-slate-600">|</span>
              <span className="inline-flex items-center gap-1 text-[11px] text-brand-sky font-medium">
                <MapPin className="w-3 h-3" />
                Bahawalpur, PK
              </span>
            </div>

            {/* Main Headline */}
            <h1
              ref={headlineRef}
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white tracking-tight leading-[1.12] mb-6"
            >
              Turning Conversations Into{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-cyan-300 to-brand-indigo">
                Connections,
              </span>{' '}
              And Ideas Into{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-brand-sky">
                Digital Experiences.
              </span>
            </h1>

            {/* Subheading */}
            <p
              ref={subRef}
              className="text-base sm:text-lg text-slate-300 font-light max-w-2xl leading-relaxed mb-4"
            >
              <strong className="font-semibold text-white">
                Customer Support Specialist
              </strong>{' '}
              | Sales & Client Communication Professional | Digital Marketing Freelancer |{' '}
              <span className="text-brand-sky font-medium">AI Enthusiast</span>
            </p>

            {/* Compact Professional Summary Preview */}
            <p className="text-sm text-slate-400 max-w-xl leading-relaxed mb-8 border-l-2 border-brand-sky/40 pl-4 py-0.5">
              Experienced in live verification and closing for international campaigns, field brand advocacy, 
              and growth consulting across 10+ creator accounts — backed by certified AI foundations from Google Cloud and Anthropic.
            </p>

            {/* CTA Buttons */}
            <div
              ref={ctaRef}
              className="flex flex-wrap items-center gap-3.5 w-full sm:w-auto mb-10"
            >
              {/* Primary: View My Experience */}
              <a
                href="#experience"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl font-semibold text-sm text-obsidian-950 bg-gradient-to-r from-brand-sky via-cyan-300 to-white hover:from-white hover:to-brand-sky transition-all duration-300 shadow-lg shadow-brand-sky/25 hover:shadow-brand-sky/40 hover:-translate-y-0.5 group"
              >
                <Briefcase className="w-4 h-4 text-obsidian-950" />
                <span>View My Experience</span>
                <ArrowRight className="w-4 h-4 text-obsidian-950 group-hover:translate-x-1 transition-transform" />
              </a>

              {/* Secondary: Explore Certificates */}
              <a
                href="#certificates"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl font-medium text-sm text-slate-200 bg-obsidian-900/90 hover:bg-obsidian-800 border border-white/10 hover:border-brand-sky/40 transition-all hover:-translate-y-0.5 shadow-sm group"
              >
                <Award className="w-4 h-4 text-brand-sky group-hover:scale-110 transition-transform" />
                <span>Explore My Certificates</span>
              </a>

              {/* Tertiary: Download CV */}
              <a
                href={personalInfo.cvUrl}
                download="Hasnain_Zahid_CV.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl font-medium text-sm text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all hover:-translate-y-0.5 group"
              >
                <Download className="w-4 h-4 text-brand-sky group-hover:translate-y-0.5 transition-transform" />
                <span>Download My CV</span>
              </a>
            </div>

            {/* Quick Stats Grid */}
            <div
              ref={statsRef}
              className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full pt-6 border-t border-white/10"
            >
              {personalInfo.stats.map((stat, i) => (
                <div key={i} className="flex flex-col">
                  <span className="font-heading font-black text-2xl sm:text-3xl text-white tracking-tight">
                    {stat.value}
                  </span>
                  <span className="text-xs font-medium text-slate-300">
                    {stat.label}
                  </span>
                  <span className="text-[11px] text-slate-500 truncate">
                    {stat.detail}
                  </span>
                </div>
              ))}
            </div>

          </div>

          {/* Right Column: 3D Interactive Canvas & Floating Info Badges */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            
            {/* The Interactive 3D Canvas */}
            <div className="w-full max-w-[500px] aspect-square relative z-10">
              <Hero3D />
            </div>

            {/* Floating Credential Pill 1: Google Cloud & Anthropic */}
            <div className="absolute -top-4 -left-4 sm:left-4 z-20 hidden sm:flex items-center gap-3 p-3 rounded-2xl glass-card shadow-xl border border-white/10 animate-float-slow">
              <div className="w-9 h-9 rounded-xl bg-brand-sky/20 border border-brand-sky/30 flex items-center justify-center text-brand-sky">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>Google & Anthropic</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-[11px] text-slate-400">Certified AI Foundations</div>
              </div>
            </div>

            {/* Floating Credential Pill 2: Call Center & Sales Verification */}
            <div className="absolute -bottom-2 -right-2 sm:right-4 z-20 hidden sm:flex items-center gap-3 p-3 rounded-2xl glass-card shadow-xl border border-white/10 animate-float-slow [animation-delay:2s]">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>Final Expense Veteran</span>
                  <span className="text-[10px] text-emerald-400 font-mono">6M+3M</span>
                </div>
                <div className="text-[11px] text-slate-400">Verification & Closing Agent</div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
