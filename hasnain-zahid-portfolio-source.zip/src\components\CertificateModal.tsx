import React, { useEffect } from 'react';
import { CertificateItem } from '../types';
import { 
  X, 
  ExternalLink, 
  Download, 
  Award, 
  Calendar, 
  Clock, 
  UserCheck, 
  CheckCircle2, 
  ShieldCheck,
  Copy,
  Check
} from 'lucide-react';

interface CertificateModalProps {
  cert: CertificateItem | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ cert, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (cert) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [cert, onClose]);

  if (!cert) return null;

  const copyCredentialId = () => {
    if (cert.credentialId) {
      navigator.clipboard.writeText(cert.credentialId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-10 animate-in fade-in duration-200">
      {/* Dark backdrop blur */}
      <div 
        className="fixed inset-0 bg-obsidian-950/85 backdrop-blur-xl transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Dialog Content */}
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-obsidian-900 border border-white/15 rounded-3xl shadow-2xl flex flex-col overflow-hidden z-10">
        
        {/* Modal Top Bar */}
        <div className="p-5 sm:px-8 border-b border-white/10 flex items-center justify-between bg-obsidian-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-sky/20 border border-brand-sky/30 flex items-center justify-center text-brand-sky">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono uppercase tracking-wider text-brand-sky">
                  {cert.issuer}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Authentic Credential
                </span>
              </div>
              <h3 className="font-heading font-bold text-lg text-white">
                {cert.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors focus:outline-none"
            aria-label="Close certificate preview"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Two-column responsive view */}
        <div className="overflow-y-auto p-5 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Visual Certificate Preview Container */}
            <div className="lg:col-span-7 bg-obsidian-950 rounded-2xl border border-white/10 p-3 sm:p-4 flex flex-col items-center justify-center min-h-[300px]">
              {cert.fileType === 'image' ? (
                <div className="w-full flex items-center justify-center p-4">
                  <img
                    src={cert.fileUrl}
                    alt={cert.title}
                    className="max-h-[380px] w-auto object-contain rounded-xl shadow-lg border border-white/10"
                  />
                </div>
              ) : (
                <div className="w-full flex flex-col items-center">
                  {/* Embedded PDF iframe / object viewer */}
                  <div className="w-full aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 border border-white/10 relative">
                    <iframe
                      src={`${cert.fileUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                      title={cert.title}
                      className="w-full h-full border-0"
                    />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-2 font-mono">
                    Direct PDF rendering from authentic project credential file
                  </p>
                </div>
              )}
            </div>

            {/* Credential Metadata & Verification Details */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Credential Description
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {cert.description}
                </p>
              </div>

              {/* Metadata Key-Value Grid */}
              <div className="space-y-3 p-4 rounded-2xl bg-obsidian-950/60 border border-white/5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-brand-sky" /> Issuing Organization:
                  </span>
                  <span className="font-semibold text-white">{cert.issuer}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-brand-sky" /> Date:
                  </span>
                  <span className="text-slate-200 font-mono">{cert.date}</span>
                </div>

                {cert.instructor && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-brand-sky" /> Instructor:
                    </span>
                    <span className="text-slate-200">{cert.instructor}</span>
                  </div>
                )}

                {cert.duration && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-brand-sky" /> Duration:
                    </span>
                    <span className="text-slate-200 font-mono">{cert.duration}</span>
                  </div>
                )}

                {cert.credentialId && (
                  <div className="pt-2 border-t border-white/5 flex flex-col gap-1.5">
                    <span className="text-slate-400 text-[11px]">Certificate Identifier:</span>
                    <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-obsidian-900 border border-white/5 font-mono text-[11px] text-brand-sky">
                      <span className="truncate">{cert.credentialId}</span>
                      <button
                        onClick={copyCredentialId}
                        className="p-1 hover:text-white transition-colors"
                        title="Copy Certificate ID"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Skills Validated */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                  Skills Validated
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {cert.skillsHighlighted.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-brand-sky/10 text-brand-sky border border-brand-sky/20"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row gap-3">
                <a
                  href={cert.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-obsidian-950 bg-gradient-to-r from-brand-sky to-white hover:from-white hover:to-brand-sky transition-all shadow-md"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-obsidian-950" />
                  Open Original File
                </a>

                <a
                  href={cert.fileUrl}
                  download
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-brand-sky" />
                  Download
                </a>
              </div>

            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
