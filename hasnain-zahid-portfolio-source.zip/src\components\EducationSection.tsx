import React from 'react';
import { educationList } from '../data/portfolioData';
import { 
  GraduationCap, 
  Calendar, 
  Building, 
  CheckCircle2, 
  Sparkles, 
  BookOpen, 
  Award,
  Clock
} from 'lucide-react';

export const EducationSection: React.FC = () => {
  return (
    <section id="education" className="py-24 relative bg-obsidian-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-sky/10 border border-brand-sky/20 text-brand-sky text-xs font-semibold uppercase tracking-wider mb-4">
              <GraduationCap className="w-3.5 h-3.5" />
              09 — Academic Background & Education
            </div>
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight">
              Computer Science Foundation &{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-sky via-brand-indigo to-white">
                Continuous Academic Learning.
              </span>
            </h2>
          </div>
          <div className="md:text-right">
            <span className="text-xs font-mono text-slate-500">ACADEMIC BOARD</span>
            <p className="text-xs text-slate-400">BISE Bahawalpur Accredited Institutions</p>
          </div>
        </div>

        {/* Education Timeline Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {educationList.map((item, idx) => (
            <div
              key={idx}
              className="relative p-8 rounded-3xl glass-card border border-white/10 hover:border-brand-sky/40 transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-2xl bg-brand-sky/15 border border-brand-sky/30 flex items-center justify-center text-brand-sky">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-white/5 text-slate-300 border border-white/10">
                      {item.period}
                    </span>
                  </div>
                </div>

                <div className="mb-4">
                  <span className="text-xs font-mono uppercase tracking-wider text-brand-sky block mb-1">
                    {item.field}
                  </span>
                  <h3 className="font-heading font-bold text-2xl text-white">
                    {item.degree}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                    <Building className="w-3.5 h-3.5 text-slate-500" />
                    <span>{item.institution}</span>
                    <span className="text-slate-600">•</span>
                    <span>{item.boardOrAuthority}</span>
                  </div>
                </div>

                {/* Status / Grade Badge */}
                <div className="my-5 p-3.5 rounded-xl bg-obsidian-950/80 border border-white/5 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Academic Standing:</span>
                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                    {item.gradeOrMarks ? (
                      <>
                        <Award className="w-3.5 h-3.5 text-emerald-400" />
                        {item.gradeOrMarks}
                      </>
                    ) : (
                      <>
                        <Clock className="w-3.5 h-3.5 text-brand-sky" />
                        {item.status}
                      </>
                    )}
                  </span>
                </div>

                {/* Academic Highlights */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    Curriculum & Key Highlights
                  </h4>
                  <ul className="space-y-2">
                    {item.highlights.map((hl, hIdx) => (
                      <li
                        key={hIdx}
                        className="flex items-start gap-2 text-xs text-slate-300 leading-relaxed"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-brand-sky shrink-0 mt-0.5" />
                        <span>{hl}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span>Verified Educational Record</span>
                <span>Ahmed Pur East, PK</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
